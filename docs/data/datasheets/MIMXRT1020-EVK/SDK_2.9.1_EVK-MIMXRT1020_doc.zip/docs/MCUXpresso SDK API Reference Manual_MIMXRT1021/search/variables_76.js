var searchData=
[
  ['validityconfig',['validityConfig',['../a00072.html#a662ae617d9706faedff59b4e7ebfc563',1,'spdif_config_t']]],
  ['version',['version',['../a00060.html#a23b8ed9688825316750d697b524c7d18',1,'sd_card_t']]]
];
