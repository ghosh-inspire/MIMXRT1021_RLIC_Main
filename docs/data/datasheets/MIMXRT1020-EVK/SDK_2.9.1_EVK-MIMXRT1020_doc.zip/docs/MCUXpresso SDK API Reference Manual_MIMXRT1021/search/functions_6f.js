var searchData=
[
  ['ocotp_5fcheckbusystatus',['OCOTP_CheckBusyStatus',['../a00053.html#gaa3040092099624ec476dd81bd022712c',1,'fsl_ocotp.h']]],
  ['ocotp_5fcheckerrorstatus',['OCOTP_CheckErrorStatus',['../a00053.html#gaf0ee0166ccd35b0273d468b7eb72c954',1,'fsl_ocotp.h']]],
  ['ocotp_5fclearerrorstatus',['OCOTP_ClearErrorStatus',['../a00053.html#gad9294be0c39be4dfaa1eea436ac85171',1,'fsl_ocotp.h']]],
  ['ocotp_5fdeinit',['OCOTP_Deinit',['../a00053.html#gaafffa3b5fe3f1f69f077e88ba5a7e107',1,'fsl_ocotp.h']]],
  ['ocotp_5fgetversion',['OCOTP_GetVersion',['../a00053.html#ga38c12a5cb815d9330cd8f2c04e8e1ec5',1,'fsl_ocotp.h']]],
  ['ocotp_5finit',['OCOTP_Init',['../a00053.html#ga54480b3c489116b8cb76053b16f02c89',1,'fsl_ocotp.h']]],
  ['ocotp_5freadfuseshadowregister',['OCOTP_ReadFuseShadowRegister',['../a00053.html#gaecc991ccf4be0c49286fb13cba97e389',1,'fsl_ocotp.h']]],
  ['ocotp_5freadfuseshadowregisterext',['OCOTP_ReadFuseShadowRegisterExt',['../a00053.html#gaa1b0f813fa5ca43225d71d9218c48a28',1,'fsl_ocotp.h']]],
  ['ocotp_5freloadshadowregister',['OCOTP_ReloadShadowRegister',['../a00053.html#ga7a7b1cd03383fafde15157a06fdda557',1,'fsl_ocotp.h']]],
  ['ocotp_5fwritefuseshadowregister',['OCOTP_WriteFuseShadowRegister',['../a00053.html#ga43636ab96125958c9a14fe82c176e33e',1,'fsl_ocotp.h']]],
  ['ocotp_5fwritefuseshadowregisterwithlock',['OCOTP_WriteFuseShadowRegisterWithLock',['../a00053.html#ga4f837c7b4a66ffe3153f2975fd5c6388',1,'fsl_ocotp.h']]]
];
