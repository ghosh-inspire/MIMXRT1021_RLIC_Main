var searchData=
[
  ['usdhc_5fadma1_5fdescriptor_5ft',['usdhc_adma1_descriptor_t',['../a00076.html#gaeaf8981c77f59c815328efb192f39bae',1,'fsl_usdhc.h']]],
  ['usdhc_5ftransfer_5ffunction_5ft',['usdhc_transfer_function_t',['../a00076.html#gae5d7e4ca4e99c90277352ad3ab9d8b6e',1,'fsl_usdhc.h']]]
];
