var searchData=
[
  ['ocr',['ocr',['../a00051.html#a0b3899f0be098f696fd5bc212d4b597e',1,'mmc_card_t::ocr()'],['../a00060.html#a4dfdb06355545a94755d7b7b8b8bb708',1,'sd_card_t::ocr()'],['../a00061.html#a493c409455409991a2af4ae08e31b386',1,'_sdio_card::ocr()']]],
  ['ocrambanknum',['ocramBankNum',['../a00037.html#a17779c83dfb613e244bccc31c32ae863',1,'flexram_allocate_ram_t']]],
  ['operationvoltage',['operationVoltage',['../a00060.html#aef60a9196a9789f243660bb76f3a0ef2',1,'sd_card_t::operationVoltage()'],['../a00061.html#a7aecd4677ec222958c8daad36033933d',1,'_sdio_card::operationVoltage()']]],
  ['outputclock_5fhz',['outputClock_HZ',['../a00016.html#aa437baa5261123cd810488ac65e201dd',1,'da7212_pll_config_t::outputClock_HZ()'],['../a00078.html#ab58ab790fa57e24806ef762dc9cbbbae',1,'wm8904_fll_config_t::outputClock_HZ()']]],
  ['outputlogic',['outputLogic',['../a00039.html#a9d37ffd9a2943f10a91095759bd52da5',1,'gpio_pin_config_t']]],
  ['overcurrentthreshold',['OverCurrentThreshold',['../a00017.html#a2cbfaed67e0e2e90e77fce311a24e8c4',1,'dcdc_detection_config_t']]]
];
