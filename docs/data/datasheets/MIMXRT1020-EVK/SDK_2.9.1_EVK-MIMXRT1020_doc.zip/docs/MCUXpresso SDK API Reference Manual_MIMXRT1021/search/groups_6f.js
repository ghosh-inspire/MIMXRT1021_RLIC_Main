var searchData=
[
  ['ocotp_3a_20on_20chip_20one_2dtime_20programmable_20controller_2e',['OCOTP: On Chip One-Time Programmable controller.',['../a00053.html',1,'']]]
];
