var searchData=
[
  ['xbara_3a_20inter_2dperipheral_20crossbar_20switch',['XBARA: Inter-Peripheral Crossbar Switch',['../a00080.html',1,'']]],
  ['xbarb_3a_20inter_2dperipheral_20crossbar_20switch',['XBARB: Inter-Peripheral Crossbar Switch',['../a00275.html',1,'']]]
];
