var searchData=
[
  ['nbytes',['NBYTES',['../a00020.html#ada2a3af3cbf20ed38a3669c963d49f7d',1,'edma_tcd_t::NBYTES()'],['../a00026.html#a12a81c4048e7c1cc3d82b9030631a049',1,'_flexio_camera_edma_handle::nbytes()'],['../a00030.html#a0c4f3ae0b658cf448c53bb0c85859989',1,'_flexio_i2s_edma_handle::nbytes()'],['../a00034.html#a32e1ff6188daf9c28eea501cf7585761',1,'_flexio_spi_master_edma_handle::nbytes()'],['../a00036.html#a31c522fa133f42dc19a10ce3707a3546',1,'_flexio_uart_edma_handle::nbytes()'],['../a00043.html#a71e19bdaa2d6ed8e95d4b25497a45149',1,'_lpi2c_master_edma_handle::nbytes()'],['../a00046.html#a6cb0ef8b643f0c8da471897277a79e11',1,'_lpspi_master_edma_handle::nbytes()'],['../a00046.html#ac4304fd510994667fcc72cf37ef1345a',1,'_lpspi_slave_edma_handle::nbytes()'],['../a00048.html#a7ffb3be259d932a6a9f7e86aed4cc790',1,'_lpuart_edma_handle::nbytes()'],['../a00059.html#a061d53e53af802d59eca8bc3171297ce',1,'sai_edma_handle::nbytes()'],['../a00073.html#a64d0df1456c3e227075740856ef9792f',1,'_spdif_edma_handle::nbytes()']]],
  ['needrestart',['needRestart',['../a00028.html#aaf7dbf9de526b48d31035afdf18a2d8d',1,'_flexio_i2c_master_handle']]],
  ['nointeralalign',['noInteralAlign',['../a00051.html#a306fbd3a3215259f9b380f8e8423f172',1,'mmc_card_t::noInteralAlign()'],['../a00060.html#a089143022f4fcf62251935db4ee7e996',1,'sd_card_t::noInteralAlign()']]],
  ['nointernalalign',['noInternalAlign',['../a00061.html#aa3a92263c58ded5911a0c0bce688352f',1,'_sdio_card']]],
  ['notification_20framework',['Notification Framework',['../a00052.html',1,'']]],
  ['notifier_5fcallback_5fconfig_5ft',['notifier_callback_config_t',['../a00052.html#a00425',1,'']]],
  ['notifier_5fcallback_5ft',['notifier_callback_t',['../a00052.html#gafd1d8cc01c496de8b4cd3990ff85415c',1,'fsl_notifier.h']]],
  ['notifier_5fcallback_5ftype_5ft',['notifier_callback_type_t',['../a00052.html#gaad75237e3cea51f8315cf6577b35db91',1,'fsl_notifier.h']]],
  ['notifier_5fcreatehandle',['NOTIFIER_CreateHandle',['../a00052.html#gaa2dfe33b4724d9c1025acdde1b1b3c31',1,'fsl_notifier.h']]],
  ['notifier_5fgeterrorcallbackindex',['NOTIFIER_GetErrorCallbackIndex',['../a00052.html#ga9736632c3beca486ec3f8dab504b839c',1,'fsl_notifier.h']]],
  ['notifier_5fhandle_5ft',['notifier_handle_t',['../a00052.html#a00426',1,'']]],
  ['notifier_5fnotification_5fblock_5ft',['notifier_notification_block_t',['../a00052.html#a00427',1,'']]],
  ['notifier_5fnotification_5ftype_5ft',['notifier_notification_type_t',['../a00052.html#ga5ee4314c2a52ee0af61985e7163a1be9',1,'fsl_notifier.h']]],
  ['notifier_5fpolicy_5ft',['notifier_policy_t',['../a00052.html#ga62e961564dc31b8155d128a3f6566409',1,'fsl_notifier.h']]],
  ['notifier_5fswitchconfig',['NOTIFIER_SwitchConfig',['../a00052.html#ga9ca08c8f6fa9a7bafa9ecbe08603cd97',1,'fsl_notifier.h']]],
  ['notifier_5fuser_5fconfig_5ft',['notifier_user_config_t',['../a00052.html#gad0b6e919f3ff69992b36a2734a650ec7',1,'fsl_notifier.h']]],
  ['notifier_5fuser_5ffunction_5ft',['notifier_user_function_t',['../a00052.html#gacb6a6d6f99e6ddfbb96dae53382949b2',1,'fsl_notifier.h']]],
  ['notifytype',['notifyType',['../a00052.html#a2ca3b1a52e315e072a8ab48fcc1dd62a',1,'notifier_notification_block_t']]],
  ['numerator',['numerator',['../a00011.html#a42c71fd94e7cb5d25c7e3a648c4769e5',1,'clock_sys_pll_config_t::numerator()'],['../a00011.html#a7cdf80b89c5dc408bcace6cd2e7096e5',1,'clock_audio_pll_config_t::numerator()']]]
];
