var searchData=
[
  ['g_5flpspidummydata',['g_lpspiDummyData',['../a00045.html#ga95e4847cd333277614975d46280df9dd',1,'fsl_lpspi.h']]],
  ['g_5frtcxtalfreq',['g_rtcXtalFreq',['../a00011.html#ga58163eb0a85bd5a9e19b6aff16d47920',1,'fsl_clock.h']]],
  ['g_5fserialhandle',['g_serialHandle',['../a00276.html#gaad3c4240a1364156a239471ccdb9aa0b',1,'fsl_debug_console.h']]],
  ['g_5fxtalfreq',['g_xtalFreq',['../a00011.html#gaa8b59ed5be618b5e5339efcbc4564e78',1,'fsl_clock.h']]],
  ['gain',['gain',['../a00072.html#af2eeb1f3e4a229d81b00a2e293bd5b8f',1,'spdif_config_t']]],
  ['gatherresidualwrites',['gatherResidualWrites',['../a00018.html#a9bf6c28d293292f7ab36414ac55d8e6b',1,'dcp_config_t']]],
  ['genericcmd6timeout',['genericCMD6Timeout',['../a00050.html#aea027acf75e372dbe29ad96ddedf5978',1,'mmc_extended_csd_t']]]
];
