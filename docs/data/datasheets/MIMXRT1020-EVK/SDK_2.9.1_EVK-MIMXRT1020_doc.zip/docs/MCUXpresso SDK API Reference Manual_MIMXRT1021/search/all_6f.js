var searchData=
[
  ['ocotp_3a_20on_20chip_20one_2dtime_20programmable_20controller_2e',['OCOTP: On Chip One-Time Programmable controller.',['../a00053.html',1,'']]],
  ['ocotp_5fcheckbusystatus',['OCOTP_CheckBusyStatus',['../a00053.html#gaa3040092099624ec476dd81bd022712c',1,'fsl_ocotp.h']]],
  ['ocotp_5fcheckerrorstatus',['OCOTP_CheckErrorStatus',['../a00053.html#gaf0ee0166ccd35b0273d468b7eb72c954',1,'fsl_ocotp.h']]],
  ['ocotp_5fclearerrorstatus',['OCOTP_ClearErrorStatus',['../a00053.html#gad9294be0c39be4dfaa1eea436ac85171',1,'fsl_ocotp.h']]],
  ['ocotp_5fdeinit',['OCOTP_Deinit',['../a00053.html#gaafffa3b5fe3f1f69f077e88ba5a7e107',1,'fsl_ocotp.h']]],
  ['ocotp_5fgetversion',['OCOTP_GetVersion',['../a00053.html#ga38c12a5cb815d9330cd8f2c04e8e1ec5',1,'fsl_ocotp.h']]],
  ['ocotp_5finit',['OCOTP_Init',['../a00053.html#ga54480b3c489116b8cb76053b16f02c89',1,'fsl_ocotp.h']]],
  ['ocotp_5freadfuseshadowregister',['OCOTP_ReadFuseShadowRegister',['../a00053.html#gaecc991ccf4be0c49286fb13cba97e389',1,'fsl_ocotp.h']]],
  ['ocotp_5freadfuseshadowregisterext',['OCOTP_ReadFuseShadowRegisterExt',['../a00053.html#gaa1b0f813fa5ca43225d71d9218c48a28',1,'fsl_ocotp.h']]],
  ['ocotp_5freloadshadowregister',['OCOTP_ReloadShadowRegister',['../a00053.html#ga7a7b1cd03383fafde15157a06fdda557',1,'fsl_ocotp.h']]],
  ['ocotp_5ftiming_5ft',['ocotp_timing_t',['../a00053.html#a00428',1,'']]],
  ['ocotp_5fwritefuseshadowregister',['OCOTP_WriteFuseShadowRegister',['../a00053.html#ga43636ab96125958c9a14fe82c176e33e',1,'fsl_ocotp.h']]],
  ['ocotp_5fwritefuseshadowregisterwithlock',['OCOTP_WriteFuseShadowRegisterWithLock',['../a00053.html#ga4f837c7b4a66ffe3153f2975fd5c6388',1,'fsl_ocotp.h']]],
  ['ocr',['ocr',['../a00051.html#a0b3899f0be098f696fd5bc212d4b597e',1,'mmc_card_t::ocr()'],['../a00060.html#a4dfdb06355545a94755d7b7b8b8bb708',1,'sd_card_t::ocr()'],['../a00061.html#a493c409455409991a2af4ae08e31b386',1,'_sdio_card::ocr()']]],
  ['ocram_5fexsc_5fclocks',['OCRAM_EXSC_CLOCKS',['../a00011.html#gaae92c633a9798e714c4a291b3fa78a3d',1,'fsl_clock.h']]],
  ['ocrambanknum',['ocramBankNum',['../a00037.html#a17779c83dfb613e244bccc31c32ae863',1,'flexram_allocate_ram_t']]],
  ['operationvoltage',['operationVoltage',['../a00060.html#aef60a9196a9789f243660bb76f3a0ef2',1,'sd_card_t::operationVoltage()'],['../a00061.html#a7aecd4677ec222958c8daad36033933d',1,'_sdio_card::operationVoltage()']]],
  ['outputclock_5fhz',['outputClock_HZ',['../a00016.html#aa437baa5261123cd810488ac65e201dd',1,'da7212_pll_config_t::outputClock_HZ()'],['../a00078.html#ab58ab790fa57e24806ef762dc9cbbbae',1,'wm8904_fll_config_t::outputClock_HZ()']]],
  ['outputlogic',['outputLogic',['../a00039.html#a9d37ffd9a2943f10a91095759bd52da5',1,'gpio_pin_config_t']]],
  ['overcurrentthreshold',['OverCurrentThreshold',['../a00017.html#a2cbfaed67e0e2e90e77fce311a24e8c4',1,'dcdc_detection_config_t']]]
];
