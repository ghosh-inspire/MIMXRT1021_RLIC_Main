var searchData=
[
  ['gpc_3a_20general_20power_20controller_20driver',['GPC: General Power Controller Driver',['../a00265.html',1,'']]],
  ['gpio_3a_20general_2dpurpose_20input_2foutput_20driver',['GPIO: General-Purpose Input/Output Driver',['../a00039.html',1,'']]],
  ['gpt_3a_20general_20purpose_20timer',['GPT: General Purpose Timer',['../a00040.html',1,'']]]
];
