var searchData=
[
  ['pit_3a_20periodic_20interrupt_20timer',['PIT: Periodic Interrupt Timer',['../a00054.html',1,'']]],
  ['pmu_3a_20power_20management_20unit',['PMU: Power Management Unit',['../a00271.html',1,'']]],
  ['pwm_3a_20pulse_20width_20modulator',['PWM: Pulse Width Modulator',['../a00055.html',1,'']]]
];
