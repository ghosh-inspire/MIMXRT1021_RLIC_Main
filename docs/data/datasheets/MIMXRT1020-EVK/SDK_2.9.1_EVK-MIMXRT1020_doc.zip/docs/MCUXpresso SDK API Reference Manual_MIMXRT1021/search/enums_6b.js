var searchData=
[
  ['kpp_5finterrupt_5fenable_5ft',['kpp_interrupt_enable_t',['../a00041.html#ga405aea9bdb57ab7a5a7d0aecdc0edc72',1,'fsl_kpp.h']]],
  ['kpp_5fsync_5foperation_5ft',['kpp_sync_operation_t',['../a00041.html#ga0c44e479c6d310cf4d9a701c09f73485',1,'fsl_kpp.h']]]
];
