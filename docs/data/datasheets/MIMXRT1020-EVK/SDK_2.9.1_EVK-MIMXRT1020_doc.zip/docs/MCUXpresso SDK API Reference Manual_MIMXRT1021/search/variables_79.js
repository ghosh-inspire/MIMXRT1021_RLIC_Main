var searchData=
[
  ['year',['year',['../a00070.html#ad208ce2822d4237a24aa334378163d8e',1,'snvs_hp_rtc_datetime_t::year()'],['../a00071.html#a03a4361ff2481ab7ed890c60f3ac68b7',1,'snvs_lp_srtc_datetime_t::year()']]]
];
