var searchData=
[
  ['romapi_20driver',['ROMAPI Driver',['../a00255.html',1,'']]],
  ['rtwdog_3a_2032_2dbit_20watchdog_20timer',['RTWDOG: 32-bit Watchdog Timer',['../a00057.html',1,'']]]
];
