var a00030 =
[
    [ "flexio_i2s_edma_handle_t", "a00030.html#a00297", [
      [ "dmaHandle", "a00030.html#a12a2f2c760cbe15e7fb1f0951a0c7d9b", null ],
      [ "bytesPerFrame", "a00030.html#abd5c06ded3088c6359591a31379ad075", null ],
      [ "nbytes", "a00030.html#a0c4f3ae0b658cf448c53bb0c85859989", null ],
      [ "state", "a00030.html#a1914d6f6e3efa0da7924366c731ad11b", null ],
      [ "callback", "a00030.html#a90f9cdd7736391eeb16a983b2644c0f8", null ],
      [ "userData", "a00030.html#a34ceb56e6f77b98a7318c84166fe03df", null ],
      [ "tcd", "a00030.html#aa8bbd32f95ed33f3c19038edffb4d347", null ],
      [ "queue", "a00030.html#a8d7523f896a595c8e08b569fe48827eb", null ],
      [ "transferSize", "a00030.html#a19bca6ba23dcef0fe530fa94e62c0ef9", null ],
      [ "queueUser", "a00030.html#a04c1f185a11c9e9004163b14eb510525", null ],
      [ "queueDriver", "a00030.html#a8652d38a3a09641beee105cfb6d744c3", null ]
    ] ],
    [ "FSL_FLEXIO_I2S_EDMA_DRIVER_VERSION", "a00030.html#gaa43bc2ccc6c5bfc9c6a10fa1dc814dc5", null ],
    [ "flexio_i2s_edma_callback_t", "a00030.html#gac8ad14418234f5c3f326cad96b2c72d2", null ],
    [ "FLEXIO_I2S_TransferTxCreateHandleEDMA", "a00030.html#ga0a064c3820e9d9cb89b322f44254129b", null ],
    [ "FLEXIO_I2S_TransferRxCreateHandleEDMA", "a00030.html#ga46e255cc70f7da87ff82b9a1c376d26c", null ],
    [ "FLEXIO_I2S_TransferSetFormatEDMA", "a00030.html#gaea6d35cc631a51dbadca239bb0c59478", null ],
    [ "FLEXIO_I2S_TransferSendEDMA", "a00030.html#gab9611613f8b7e9b2d4da51d709db661e", null ],
    [ "FLEXIO_I2S_TransferReceiveEDMA", "a00030.html#ga440a4f8f9a6d859f2c8078d5209e74ad", null ],
    [ "FLEXIO_I2S_TransferAbortSendEDMA", "a00030.html#ga965a1f1fb9a4bea6808afb4d060121d2", null ],
    [ "FLEXIO_I2S_TransferAbortReceiveEDMA", "a00030.html#ga8dfa5e3058760202f87d2ff01fca285a", null ],
    [ "FLEXIO_I2S_TransferGetSendCountEDMA", "a00030.html#ga866f520fa4d5b421700563ddbe28b375", null ],
    [ "FLEXIO_I2S_TransferGetReceiveCountEDMA", "a00030.html#gabbeb9ad1ffd98e0a371cfa14d513d8d1", null ]
];