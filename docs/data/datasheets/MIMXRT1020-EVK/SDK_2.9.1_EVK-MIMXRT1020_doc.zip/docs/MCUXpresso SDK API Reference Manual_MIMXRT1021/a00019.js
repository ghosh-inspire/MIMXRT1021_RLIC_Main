var a00019 =
[
    [ "dcp_hash_ctx_t", "a00019.html#a00350", null ],
    [ "DCP_SHA_BLOCK_SIZE", "a00019.html#gaaaf05095de831681825b475fca16ca14", null ],
    [ "DCP_HASH_BLOCK_SIZE", "a00019.html#ga6c48bdbcc2a96ef138e5de5393fe5965", null ],
    [ "DCP_HASH_CTX_SIZE", "a00019.html#gaa5741738e5700607fd0ab7da6228bba2", null ],
    [ "dcp_hash_algo_t", "a00019.html#gad4fd0f71415f2d064685219f5650d2ed", [
      [ "kDCP_Sha1", "a00019.html#ggad4fd0f71415f2d064685219f5650d2eda789e6da5cc19aa6d5eae061fbdd918d9", null ],
      [ "kDCP_Sha256", "a00019.html#ggad4fd0f71415f2d064685219f5650d2eda8e1e38a094ad5bb89f323f29f66eb4b9", null ],
      [ "kDCP_Crc32", "a00019.html#ggad4fd0f71415f2d064685219f5650d2eda1747e58c83642f2104c68049a44ce69e", null ]
    ] ],
    [ "DCP_HASH_Init", "a00019.html#gad343ac658a1d1118abb53a91b87f43cf", null ],
    [ "DCP_HASH_Update", "a00019.html#ga65d17b5c879f548b0c725d7be43d6415", null ],
    [ "DCP_HASH_Finish", "a00019.html#ga7a3ed9d163c10e27d6d30f2ee9c7093f", null ],
    [ "DCP_HASH", "a00019.html#ga4f07a7b717483d2b760cd772bc1f6df7", null ]
];