var a00289 =
[
    [ "SERIAL_PORT_UART_HANDLE_SIZE", "a00289.html#ga2109c092d5f72ef7729b0454b40e892f", null ],
    [ "SERIAL_USE_CONFIGURE_STRUCTURE", "a00289.html#ga29c0fa5c543615a75f63bdcb7e086b16", null ],
    [ "serial_port_uart_parity_mode_t", "a00289.html#ga89a4bbed0c24cfe5e085194add680ccc", [
      [ "kSerialManager_UartParityDisabled", "a00289.html#gga89a4bbed0c24cfe5e085194add680ccca208958aa923a2c50ac1192a5085ab8b1", null ],
      [ "kSerialManager_UartParityEven", "a00289.html#gga89a4bbed0c24cfe5e085194add680ccca7d9d6f05fb6e1099fdfbf1f79a699356", null ],
      [ "kSerialManager_UartParityOdd", "a00289.html#gga89a4bbed0c24cfe5e085194add680ccca15bc11791c1f07fac71c808d083515db", null ]
    ] ],
    [ "serial_port_uart_stop_bit_count_t", "a00289.html#ga8bdf0213026f54fd54c21971e07f2d56", [
      [ "kSerialManager_UartOneStopBit", "a00289.html#gga8bdf0213026f54fd54c21971e07f2d56a5caed34146b357a7061aaacfe378e039", null ],
      [ "kSerialManager_UartTwoStopBit", "a00289.html#gga8bdf0213026f54fd54c21971e07f2d56a83eb7aee91f3fd8964d283c0057880dc", null ]
    ] ]
];