var a00275 =
[
    [ "XBARB_Init", "a00275.html#gaef36940e839f28936f9415c3cb6d703f", null ],
    [ "XBARB_Deinit", "a00275.html#gad5775a6073d472b2749cc202116d1809", null ],
    [ "XBARB_SetSignalsConnection", "a00275.html#ga64a72733261fc11d061c0d7f0abe0771", null ]
];