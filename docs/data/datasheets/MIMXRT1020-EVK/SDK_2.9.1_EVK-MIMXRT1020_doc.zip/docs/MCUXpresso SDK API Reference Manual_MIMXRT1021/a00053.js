var a00053 =
[
    [ "ocotp_timing_t", "a00053.html#a00428", [
      [ "wait", "a00053.html#acd8c4f8763dcb388f62bfa50d6e97a64", null ],
      [ "relax", "a00053.html#a9fea8ef8e47c7341a275e2dae68efa0e", null ],
      [ "strobe_prog", "a00053.html#a8e99b30121ba46182baae7906e68ca21", null ],
      [ "strobe_read", "a00053.html#abef3ec7b5191795eba9de0374b4e15cc", null ]
    ] ],
    [ "FSL_OCOTP_DRIVER_VERSION", "a00053.html#ga211ad512cb6afc3a8649a61c4f887dd5", [
      [ "kStatus_OCOTP_AccessError", "a00053.html#gga1f9aebf1de3ebbf4283a4dcf73308562a6133e2fb03bd09bc490982251048c8de", null ],
      [ "kStatus_OCOTP_CrcFail", "a00053.html#gga1f9aebf1de3ebbf4283a4dcf73308562a6c5aa99c2965029cf80feaf36cd0763a", null ],
      [ "kStatus_OCOTP_ReloadError", "a00053.html#gga1f9aebf1de3ebbf4283a4dcf73308562aa1a3a69603c6973128021852a03cf9ce", null ],
      [ "kStatus_OCOTP_ProgramFail", "a00053.html#gga1f9aebf1de3ebbf4283a4dcf73308562ae3aafd3ae27db94a954965038445d240", null ],
      [ "kStatus_OCOTP_Locked", "a00053.html#gga1f9aebf1de3ebbf4283a4dcf73308562a3a38a5c2c3c0f0146c9b773e855812a6", null ]
    ] ],
    [ "OCOTP_Init", "a00053.html#ga54480b3c489116b8cb76053b16f02c89", null ],
    [ "OCOTP_Deinit", "a00053.html#gaafffa3b5fe3f1f69f077e88ba5a7e107", null ],
    [ "OCOTP_CheckBusyStatus", "a00053.html#gaa3040092099624ec476dd81bd022712c", null ],
    [ "OCOTP_CheckErrorStatus", "a00053.html#gaf0ee0166ccd35b0273d468b7eb72c954", null ],
    [ "OCOTP_ClearErrorStatus", "a00053.html#gad9294be0c39be4dfaa1eea436ac85171", null ],
    [ "OCOTP_ReloadShadowRegister", "a00053.html#ga7a7b1cd03383fafde15157a06fdda557", null ],
    [ "OCOTP_ReadFuseShadowRegister", "a00053.html#gaecc991ccf4be0c49286fb13cba97e389", null ],
    [ "OCOTP_ReadFuseShadowRegisterExt", "a00053.html#gaa1b0f813fa5ca43225d71d9218c48a28", null ],
    [ "OCOTP_WriteFuseShadowRegister", "a00053.html#ga43636ab96125958c9a14fe82c176e33e", null ],
    [ "OCOTP_WriteFuseShadowRegisterWithLock", "a00053.html#ga4f837c7b4a66ffe3153f2975fd5c6388", null ],
    [ "OCOTP_GetVersion", "a00053.html#ga38c12a5cb815d9330cd8f2c04e8e1ec5", null ]
];