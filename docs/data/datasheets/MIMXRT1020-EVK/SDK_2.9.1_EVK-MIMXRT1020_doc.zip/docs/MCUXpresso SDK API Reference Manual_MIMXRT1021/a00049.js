var a00049 =
[
    [ "lpuart_rtos_config_t", "a00049.html#a00416", [
      [ "base", "a00049.html#abf5491a7b9c911ead3f256fc61357f65", null ],
      [ "srcclk", "a00049.html#a5209f6a860555957f5d75940b2132ae5", null ],
      [ "baudrate", "a00049.html#a86b9316f7c8bc63e672f7efd09bbb86a", null ],
      [ "parity", "a00049.html#a77f066eb41ad7b46edd5a3ee9e72d700", null ],
      [ "stopbits", "a00049.html#a347be0a813260f445e7829308a58f479", null ],
      [ "buffer", "a00049.html#a355e354365fe669ddf27d8eb538c83e9", null ],
      [ "buffer_size", "a00049.html#ad8ba8f4845a222fef29714542876ae55", null ],
      [ "enableRxRTS", "a00049.html#a6bf2ba5df12af74dd4049e4377caa213", null ],
      [ "enableTxCTS", "a00049.html#adc3d995c9c3c887bb00f2252882c9526", null ],
      [ "txCtsSource", "a00049.html#a39ef6b032392c800cb96fbf3db2470f9", null ],
      [ "txCtsConfig", "a00049.html#af09c2955ab27338fac430062ae812388", null ]
    ] ],
    [ "FSL_LPUART_FREERTOS_DRIVER_VERSION", "a00049.html#gae78d379ef6bde2ad08e1fe64f1f09bf5", null ],
    [ "LPUART_RTOS_Init", "a00049.html#ga5be9370b1fa0187c194475769e7138fc", null ],
    [ "LPUART_RTOS_Deinit", "a00049.html#ga057e59dcc578ef4b303850bcd90ca50e", null ],
    [ "LPUART_RTOS_Send", "a00049.html#ga275e067e13ecc77dde83d2d7938c038e", null ],
    [ "LPUART_RTOS_Receive", "a00049.html#ga0561f87122863c6e9b20f8991a73a0fb", null ]
];