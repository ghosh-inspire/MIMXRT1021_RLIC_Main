var a00074 =
[
    [ "tempmon_config_t", "a00074.html#a00490", [
      [ "frequency", "a00074.html#a207108996ebfd8421548f96bd4d3afaf", null ],
      [ "highAlarmTemp", "a00074.html#a29aa609c1d345f5dbfb3d0d0c1cde98a", null ],
      [ "panicAlarmTemp", "a00074.html#a6d0de071c3949892a0c5f98963a84cae", null ],
      [ "lowAlarmTemp", "a00074.html#a8e01ac5214df85cfc89f67c50becffbf", null ]
    ] ],
    [ "FSL_TEMPMON_DRIVER_VERSION", "a00074.html#ga8c820cc4dbb86ea6a99e674e7f8ff1ba", null ],
    [ "tempmon_alarm_mode", "a00074.html#ga2d8a033ed3d80771d8417dbf68bfd58b", [
      [ "kTEMPMON_HighAlarmMode", "a00074.html#gga2d8a033ed3d80771d8417dbf68bfd58ba6c34f34b411e7f880a5782d0329f732f", null ],
      [ "kTEMPMON_PanicAlarmMode", "a00074.html#gga2d8a033ed3d80771d8417dbf68bfd58ba3cafbb2449dbb58abb5ef078907ba6b0", null ],
      [ "kTEMPMON_LowAlarmMode", "a00074.html#gga2d8a033ed3d80771d8417dbf68bfd58ba3b1e1531c3d0529cba956f38568140f5", null ]
    ] ],
    [ "TEMPMON_Init", "a00074.html#gad74d3cd12c87cd031afefa47a40c4ffa", null ],
    [ "TEMPMON_Deinit", "a00074.html#ga9300a134aeda04212a2e84d1ccdb3e4a", null ],
    [ "TEMPMON_GetDefaultConfig", "a00074.html#gad39681b64944bdc56124fc4dcd66a81e", null ],
    [ "TEMPMON_StartMeasure", "a00074.html#gab591e289ffce94b52811b716f9e00fbb", null ],
    [ "TEMPMON_StopMeasure", "a00074.html#ga430b69c227f54ee17e8c1f4db14fdf35", null ],
    [ "TEMPMON_GetCurrentTemperature", "a00074.html#gafd97504a28d73d0ffbd8cd4c8f0810b8", null ],
    [ "TEMPMON_SetTempAlarm", "a00074.html#ga525fe253fcf43ed6302344cd1b7f3699", null ]
];