/*
 * Copyright 2018 NXP
 * @author Bogdan Oprescu
 */
var Adapter = scriptApi.getProfile();
scriptApi.requireScript("dcdBinFile.js");
scriptApi.requireScript("testParamsFile.js");
scriptApi.requireScript("connectParamsFile.js");

function ParamsFileCreator() {
    this.createParamsFile = function(fileName) {
        var paramsFile;
        if (fileName == "dcd.bin") {
            paramsFile = new DCDBinFile();
        }
        else if (fileName.startsWith("test_")) {
              paramsFile = new TestParamsFile();
        }
        else if (fileName == "connect.json") {
            paramsFile = new ConnectParamsFile();
        } else {
            return null;
        }

        paramsFile.content = function() {
            return JSON.stringify(this.paramsDictionary, null, 4);
        }
        return paramsFile;
    }
}


generated = Adapter.getGeneratedCode();
var fileNames =Adapter.getTestParams();
var paramsFileCreator = new ParamsFileCreator();
for (index in fileNames) {
    paramsFile = paramsFileCreator.createParamsFile(fileNames[index])

    generated.add(paramsFile.content())
}

Adapter.setGeneratedCode(generated);
