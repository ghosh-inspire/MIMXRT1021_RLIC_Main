/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

scriptApi.requireScript("semcInit.js");

var DCDBinFile = function() {

    this.paramsDictionary = {
    };

    CMD_END = 0xA5A5A5A5;

    DCD_COMMANDS = {
        "unknown": -1,
        "write_value": 0,
        "write_set_bits": 1,
        "write_clear_bits": 2,
        "check_all_bits_set": 3,
        "check_all_bits_clear": 4,
    }

    content = []

    function addCommand(opId, address, value, size){
            command = []
            command[0] = opId;
            command[1] = address;
            command[2] = value;
            command[3] = size;
            content = content.concat(command);
    }

function getRegAsHexStr(value) {
    return "0x" + value.toString(16);
}

    /* get register value as Long */
    function getRegAsLong(regId) {
        return parseInt(Adapter.getValueOf(regId + ".value"), 16) >>> 0;
    }

    /* get value of property */
    function getValueOf(propId){
        value = Adapter.getValueOf(propId)
        if (value === parseInt(value, 10)) {
            return parseInt(value) >>> 0;
        }
        return value;
    }

    /** Enable all clocks */
    //memory set 0x400FC068 32 0xffffffff
    addCommand(DCD_COMMANDS["write_value"], 0x400FC068, 0xffffffff, 32);
    //memory set 0x400FC06C 32 0xffffffff
    addCommand(DCD_COMMANDS["write_value"], 0x400FC06C, 0xffffffff, 32);
    //memory set 0x400FC070 32 0xffffffff
    addCommand(DCD_COMMANDS["write_value"], 0x400FC070, 0xffffffff, 32);
    //memory set 0x400FC074 32 0xffffffff
    addCommand(DCD_COMMANDS["write_value"], 0x400FC074, 0xffffffff, 32);
    //memory set 0x400FC078 32 0xffffffff
    addCommand(DCD_COMMANDS["write_value"], 0x400FC078, 0xffffffff, 32);
    //memory set 0x400FC07C 32 0xffffffff
    addCommand(DCD_COMMANDS["write_value"], 0x400FC07C, 0xffffffff, 32);
    //memory set 0x400FC080 32 0xffffffff
    addCommand(DCD_COMMANDS["write_value"], 0x400FC080, 0xffffffff, 32);

    //memory set 0x400FC014 32 0x000A8200 # IPG_PODF: 2 divide by 3
    addCommand(DCD_COMMANDS["write_value"], 0x400FC014, 0x000A8200, 32);
    //memory set 0x400FC01C 32 0x04900001 # PERCLK_PODF: 1 divide by 2
    addCommand(DCD_COMMANDS["write_value"], 0x400FC01C, 0x04900001, 32);
    //memory set 0x400D8030 32 0x00012001 # Enable SYS PLL but keep it bypassed.
    addCommand(DCD_COMMANDS["write_value"], 0x400D8030, 0x00012001, 32);
    //memory chkbit1 0x400D8030 32 0x80000000 # wait SYS PLL enabled
    addCommand(DCD_COMMANDS["check_all_bits_set"], 0x400D8030, 0x80000000, 32);
    //memory set 0x400D8030 32 0x00002001 # Disable bypass of SYS PLL
    addCommand(DCD_COMMANDS["write_value"], 0x400D8030, 0x00002001, 32);
    //memory clrbit 0x400D8100 32 0x800000 # ungate SYS PLL PFD2
    addCommand(DCD_COMMANDS["write_clear_bits"], 0x400D8100, 0x800000, 32);

    //memory setbit 0x400FC014 32 0x20040 # SEMC clock source selection
    addCommand(DCD_COMMANDS["write_set_bits"], 0x400FC014, 0x20040, 32);

    /** # Config IOMUX */
    // memory set 0x401F8014 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8014, 0x00000000, 32);
    // memory set 0x401F8018 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8018, 0x00000000, 32);
    // memory set 0x401F801C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F801C, 0x00000000, 32);
    // memory set 0x401F8020 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8020, 0x00000000, 32);
    // memory set 0x401F8024 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8024, 0x00000000, 32);
    // memory set 0x401F8028 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8028, 0x00000000, 32);
    // memory set 0x401F802C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F802C, 0x00000000, 32);
    // memory set 0x401F8030 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8030, 0x00000000, 32);
    // memory set 0x401F8034 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8034, 0x00000000, 32);
    // memory set 0x401F8038 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8038, 0x00000000, 32);
    // memory set 0x401F803C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F803C, 0x00000000, 32);
    // memory set 0x401F8040 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8040, 0x00000000, 32);
    // memory set 0x401F8044 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8044, 0x00000000, 32);
    // memory set 0x401F8048 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8048, 0x00000000, 32);
    // memory set 0x401F804C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F804C, 0x00000000, 32);
    // memory set 0x401F8050 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8050, 0x00000000, 32);
    // memory set 0x401F8054 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8054, 0x00000000, 32);
    // memory set 0x401F8058 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8058, 0x00000000, 32);
    // memory set 0x401F805C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F805C, 0x00000000, 32);
    // memory set 0x401F8060 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8060, 0x00000000, 32);
    // memory set 0x401F8064 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8064, 0x00000000, 32);
    // memory set 0x401F8068 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8068, 0x00000000, 32);
    // memory set 0x401F806C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F806C, 0x00000000, 32);
    // memory set 0x401F8070 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8070, 0x00000000, 32);
    // memory set 0x401F8074 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8074, 0x00000000, 32);
    // memory set 0x401F8078 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8078, 0x00000000, 32);
    // memory set 0x401F807C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F807C, 0x00000000, 32);
    // memory set 0x401F8080 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8080, 0x00000000, 32);
    // memory set 0x401F8084 32 0x00000010 # EMC_28, DQS PIN, enable SION
    addCommand(DCD_COMMANDS["write_value"], 0x401F8084, 0x00000010, 32);
    // memory set 0x401F8088 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8088, 0x00000000, 32);
    // memory set 0x401F808C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F808C, 0x00000000, 32);
    // memory set 0x401F8090 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8090, 0x00000000, 32);
    // memory set 0x401F8094 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8094, 0x00000000, 32);
    // memory set 0x401F8098 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F8098, 0x00000000, 32);
    // memory set 0x401F809C 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F809C, 0x00000000, 32);
    // memory set 0x401F80A0 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F80A0, 0x00000000, 32);
    // memory set 0x401F80A4 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F80A4, 0x00000000, 32);
    // memory set 0x401F80A8 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F80A8, 0x00000000, 32);
    // memory set 0x401F80AC 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F80AC, 0x00000000, 32);
    // memory set 0x401F80B0 32 0x00000010
    addCommand(DCD_COMMANDS["write_value"], 0x401F80B0, 0x00000010, 32);
    // memory set 0x401F80B4 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F80B4, 0x00000000, 32);
    // memory set 0x401F80B8 32 0x00000000
    addCommand(DCD_COMMANDS["write_value"], 0x401F80B8, 0x00000000, 32);


    /** PAD ctrl
    * drive strength = 0x7 to increase drive strength
    * otherwise the data7 bit may fail.
    */
    // memory set 0x401F8204 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8204, 0x000110F9, 32);
    // memory set 0x401F8208 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8208, 0x000110F9, 32);
    // memory set 0x401F820C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F820C, 0x000110F9, 32);
    // memory set 0x401F8210 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8210, 0x000110F9, 32);
    // memory set 0x401F8214 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8214, 0x000110F9, 32);
    // memory set 0x401F8218 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8218, 0x000110F9, 32);
    // memory set 0x401F821C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F821C, 0x000110F9, 32);
    // memory set 0x401F8220 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8220, 0x000110F9, 32);
    // memory set 0x401F8224 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8224, 0x000110F9, 32);
    // memory set 0x401F8228 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8228, 0x000110F9, 32);
    // memory set 0x401F822C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F822C, 0x000110F9, 32);
    // memory set 0x401F8230 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8230, 0x000110F9, 32);
    // memory set 0x401F8234 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8234, 0x000110F9, 32);
    // memory set 0x401F8238 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8238, 0x000110F9, 32);
    // memory set 0x401F823C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F823C, 0x000110F9, 32);
    // memory set 0x401F8240 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8240, 0x000110F9, 32);
    // memory set 0x401F8244 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8244, 0x000110F9, 32);
    // memory set 0x401F8248 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8248, 0x000110F9, 32);
    // memory set 0x401F824C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F824C, 0x000110F9, 32);
    // memory set 0x401F8250 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8250, 0x000110F9, 32);
    // memory set 0x401F8254 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8254, 0x000110F9, 32);
    // memory set 0x401F8258 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8258, 0x000110F9, 32);
    // memory set 0x401F825C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F825C, 0x000110F9, 32);
    // memory set 0x401F8260 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8260, 0x000110F9, 32);
    // memory set 0x401F8264 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8264, 0x000110F9, 32);
    // memory set 0x401F8268 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8268, 0x000110F9, 32);
    // memory set 0x401F826C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F826C, 0x000110F9, 32);
    // memory set 0x401F8270 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8270, 0x000110F9, 32);
    // memory set 0x401F8274 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8274, 0x000110F9, 32);
    // memory set 0x401F8278 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8278, 0x000110F9, 32);
    // memory set 0x401F827C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F827C, 0x000110F9, 32);
    // memory set 0x401F8280 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8280, 0x000110F9, 32);
    // memory set 0x401F8284 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8284, 0x000110F9, 32);
    // memory set 0x401F8288 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8288, 0x000110F9, 32);
    // memory set 0x401F828C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F828C, 0x000110F9, 32);
    // memory set 0x401F8290 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8290, 0x000110F9, 32);
    // memory set 0x401F8294 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8294, 0x000110F9, 32);
    // memory set 0x401F8298 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F8298, 0x000110F9, 32);
    // memory set 0x401F829C 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F829C, 0x000110F9, 32);
    // memory set 0x401F82A0 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F82A0, 0x000110F9, 32);
    // memory set 0x401F82A4 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F82A4, 0x000110F9, 32);
    // memory set 0x401F82A8 32 0x000110F9
    addCommand(DCD_COMMANDS["write_value"], 0x401F82A8, 0x000110F9, 32);

    /** Generate DCD commands */

    semcInitCmds = buildSemcCommands(getRegAsLong, getValueOf);
    semcCmdsStr = [];
    for (index = 0; index < semcInitCmds.length; index++) {
        semcCmd = semcInitCmds[index];
        semcCmdsStr = semcCmdsStr.concat("command: " + semcCmd.command + ", address: " +  semcCmd.address + ", value: " + getRegAsHexStr(semcCmd.value) + ", size: 4");
        addCommand(DCD_COMMANDS[semcCmd.command], parseInt(Adapter.getValueOf(semcCmd.address.substring("SEMC_".length) + ".address"), 16), semcCmd.value, 32);
    }

    content = content.concat([CMD_END]);
    this.paramsDictionary['bytes'] = content;
    this.paramsDictionary['text'] = semcCmdsStr;
}
