/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

Adapter = scriptApi.getProfile();
var flexspiCmdsStr = Adapter.getGeneratedCode();

dcdCmds = { WRITE_VALUE: "write_value",
            WRITE_SET_BITS: "write_set_bits",
            WRITE_CLEAR_BITS: "write_clear_bits",
            CHECK_ALL_BITS_SET: "check_all_bits_set",
            CHECK_ALL_BITS_CLEAR: "check_all_bits_clear",
          }

FLEXSPI_LUT_KEY_VAL = 0x5AF05AF0;

NOR_CMD_LUT_SEQ_IDX_READ_NORMAL         = 0;
NOR_CMD_LUT_SEQ_IDX_READ_FAST           = 1;
NOR_CMD_LUT_SEQ_IDX_READ_FAST_QUAD      = 2;
NOR_CMD_LUT_SEQ_IDX_READSTATUS          = 3;
NOR_CMD_LUT_SEQ_IDX_WRITEENABLE         = 4;
NOR_CMD_LUT_SEQ_IDX_ERASESECTOR         = 5;
NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_SINGLE  = 6;
NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_QUAD    = 7;
NOR_CMD_LUT_SEQ_IDX_READID              = 8;
NOR_CMD_LUT_SEQ_IDX_WRITESTATUSREG      = 9;
NOR_CMD_LUT_SEQ_IDX_ENTERQPI            = 10;
NOR_CMD_LUT_SEQ_IDX_EXITQPI             = 11;
NOR_CMD_LUT_SEQ_IDX_READSTATUSREG       = 12;
NOR_CMD_LUT_SEQ_IDX_ERASECHIP           = 5;

kFLEXSPI_Command_STOP           = 0x00; /*!< Stop execution, deassert CS. */
kFLEXSPI_Command_SDR            = 0x01; /*!< Transmit Command code to Flash, using SDR mode. */
kFLEXSPI_Command_RADDR_SDR      = 0x02; /*!< Transmit Row Address to Flash, using SDR mode. */
kFLEXSPI_Command_CADDR_SDR      = 0x03; /*!< Transmit Column Address to Flash, using SDR mode. */
kFLEXSPI_Command_MODE1_SDR      = 0x04; /*!< Transmit 1-bit Mode bits to Flash, using SDR mode. */
kFLEXSPI_Command_MODE2_SDR      = 0x05; /*!< Transmit 2-bit Mode bits to Flash, using SDR mode. */
kFLEXSPI_Command_MODE4_SDR      = 0x06; /*!< Transmit 4-bit Mode bits to Flash, using SDR mode. */
kFLEXSPI_Command_MODE8_SDR      = 0x07; /*!< Transmit 8-bit Mode bits to Flash, using SDR mode. */
kFLEXSPI_Command_WRITE_SDR      = 0x08; /*!< Transmit Programming Data to Flash, using SDR mode. */
kFLEXSPI_Command_READ_SDR       = 0x09; /*!< Receive Read Data from Flash, using SDR mode. */
kFLEXSPI_Command_LEARN_SDR      = 0x0A; /*!< Receive Read Data or Preamble bit from Flash, SDR mode. */
kFLEXSPI_Command_DATSZ_SDR      = 0x0B; /*!< Transmit Read/Program Data size (byte) to Flash, SDR mode. */
kFLEXSPI_Command_DUMMY_SDR      = 0x0C; /*!< Leave data lines undriven by FlexSPI controller.*/
kFLEXSPI_Command_DUMMY_RWDS_SDR = 0x0D; /*!< Leave data lines undriven by FlexSPI controller,
                                             dummy cycles decided by RWDS. */
kFLEXSPI_Command_DDR            = 0x21; /*!< Transmit Command code to Flash, using DDR mode. */
kFLEXSPI_Command_RADDR_DDR      = 0x22; /*!< Transmit Row Address to Flash, using DDR mode. */
kFLEXSPI_Command_CADDR_DDR      = 0x23; /*!< Transmit Column Address to Flash, using DDR mode. */
kFLEXSPI_Command_MODE1_DDR      = 0x24; /*!< Transmit 1-bit Mode bits to Flash, using DDR mode. */
kFLEXSPI_Command_MODE2_DDR      = 0x25; /*!< Transmit 2-bit Mode bits to Flash, using DDR mode. */
kFLEXSPI_Command_MODE4_DDR      = 0x26; /*!< Transmit 4-bit Mode bits to Flash, using DDR mode. */
kFLEXSPI_Command_MODE8_DDR      = 0x27; /*!< Transmit 8-bit Mode bits to Flash, using DDR mode. */
kFLEXSPI_Command_WRITE_DDR      = 0x28; /*!< Transmit Programming Data to Flash, using DDR mode. */
kFLEXSPI_Command_READ_DDR       = 0x29; /*!< Receive Read Data from Flash, using DDR mode. */
kFLEXSPI_Command_LEARN_DDR      = 0x2A; /*!< Receive Read Data or Preamble bit from Flash, DDR mode. */
kFLEXSPI_Command_DATSZ_DDR      = 0x2B; /*!< Transmit Read/Program Data size (byte) to Flash, DDR mode. */
kFLEXSPI_Command_DUMMY_DDR      = 0x2C; /*!< Leave data lines undriven by FlexSPI controller.*/
kFLEXSPI_Command_DUMMY_RWDS_DDR = 0x2D; /*!< Leave data lines undriven by FlexSPI controller,
                                           dummy cycles decided by RWDS. */
kFLEXSPI_Command_JUMP_ON_CS = 0x1F;     /*!< Stop execution, deassert CS and save operand[7:0] as the
                                           instruction start pointer for next sequence */

kFLEXSPI_1PAD = 0x00; /*!< Transmit command/address and transmit/receive data only through DATA0/DATA1. */
kFLEXSPI_2PAD = 0x01; /*!< Transmit command/address and transmit/receive data only through DATA[1:0]. */
kFLEXSPI_4PAD = 0x02; /*!< Transmit command/address and transmit/receive data only through DATA[3:0]. */
kFLEXSPI_8PAD = 0x03; /*!< Transmit command/address and transmit/receive data only through DATA[7:0]. */

function flexspi_lut_seq(index, cmd0, pad0, op0, cmd1, pad1, op1) {
    seq = 0x0;
    seq = (op0 & 0xFF) | ((pad0 << 8) & 0x300) | ((cmd0 << 10) & 0xFC00) | 
        ((op1 << 16) & 0xFF0000) | ((pad1 << 24) & 0x3000000) | ((cmd1 << 26) & (0xFC000000 >>> 0));

    cmd = {command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_LUT" + index, value: seq >>> 0, size: 4};
    return cmd;
}

function buildLUTTable(getRegAsLong, getValueOf) {

    lutCmds = [];

    /* Unlock LUT for update. */
    lutCmds = lutCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_LUTKEY", value: FLEXSPI_LUT_KEY_VAL, size: 4});
    lutCmds = lutCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_LUTCR", value: 0x02, size: 4});

    /* Example of custom LUT. This LUT is for ISSI IS25WP064AJBLE QSPI Flash. You can change the bites according to manual of flash vendor. */

   /* Normal read mode - SDR */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READ_NORMAL,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x03,
                                            kFLEXSPI_Command_RADDR_SDR, kFLEXSPI_1PAD, 0x18));
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READ_NORMAL + 1,
                                            kFLEXSPI_Command_READ_SDR, kFLEXSPI_1PAD, 0x04,
                                            kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0));
   /* Fast read mode - SDR */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READ_FAST,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x0B,
                                            kFLEXSPI_Command_RADDR_SDR, kFLEXSPI_1PAD, 0x18));
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READ_FAST + 1,
                                            kFLEXSPI_Command_DUMMY_SDR, kFLEXSPI_1PAD, 0x08,
                                            kFLEXSPI_Command_READ_SDR, kFLEXSPI_1PAD, 0x04));
 
   /* Fast read quad mode - SDR */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READ_FAST_QUAD,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0xEB,
                                            kFLEXSPI_Command_RADDR_SDR, kFLEXSPI_4PAD, 0x18));
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READ_FAST_QUAD + 1,
                                            kFLEXSPI_Command_DUMMY_SDR, kFLEXSPI_4PAD, 0x06,
                                            kFLEXSPI_Command_READ_SDR, kFLEXSPI_4PAD, 0x04));
 
   /* Read extend parameters */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READSTATUS,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x81,
                                            kFLEXSPI_Command_READ_SDR, kFLEXSPI_1PAD, 0x04));
 
   /* Write Enable */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_WRITEENABLE,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x06,
                                            kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0));
 
   /* Erase Sector */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_ERASESECTOR,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0xD7,
                                            kFLEXSPI_Command_RADDR_SDR, kFLEXSPI_1PAD, 0x18));

   /* Page Program - single mode */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_SINGLE,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x02,
                                            kFLEXSPI_Command_RADDR_SDR, kFLEXSPI_1PAD, 0x18));
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_SINGLE + 1,
                                            kFLEXSPI_Command_WRITE_SDR, kFLEXSPI_1PAD, 0x04,
                                            kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0));

   /* Page Program - quad mode */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_QUAD,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x32,
                                            kFLEXSPI_Command_RADDR_SDR, kFLEXSPI_1PAD, 0x18));
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_QUAD + 1,
                                            kFLEXSPI_Command_WRITE_SDR, kFLEXSPI_4PAD, 0x04,
                                            kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0));

   /* Read ID */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READID,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x9F,
                                            kFLEXSPI_Command_READ_SDR, kFLEXSPI_1PAD, 0x04));
 
   /* Enable Quad mode */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_WRITESTATUSREG,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x01,
                                            kFLEXSPI_Command_WRITE_SDR, kFLEXSPI_1PAD, 0x04));

   /* Enter QPI mode */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_ENTERQPI,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x35,
                                            kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0));
 
   /* Exit QPI mode */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_EXITQPI,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_4PAD, 0xF5,
                                            kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0));

   /* Read status register */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_READSTATUSREG,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x05,
                                            kFLEXSPI_Command_READ_SDR, kFLEXSPI_1PAD, 0x04));
 
   /* Erase whole chip */
   lutCmds = lutCmds.concat(flexspi_lut_seq(4 * NOR_CMD_LUT_SEQ_IDX_ERASECHIP,
                                            kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0xC7,
                                            kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0));

    /* Lock LUT. */
    lutCmds = lutCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_LUTKEY", value: FLEXSPI_LUT_KEY_VAL, size: 4});
    lutCmds = lutCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_LUTCR", value: 0x01, size: 4});

    return lutCmds;
}