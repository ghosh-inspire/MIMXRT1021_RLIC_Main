/*
 * Copyright 2020 NXP
 * @author Bogdan Oprescu
 */

var TestParamsFile = function() {
    
    function getValueOf(mystring){
        var value = Adapter.getValueOf(mystring);
        return value;
    }

    function toHexStr(d) {
        return  "0x"+(Number(d).toString(16)).toUpperCase();
    }

    this.paramsDictionary = {
        "app" :
        {
            "reset" : true,
            "name" : "",
            "max_timeout" : 35000,
            "test_params" : ""
        },
        "config" :
        {
        }
    };
    testName = getValueOf("app.name");
    this.paramsDictionary["app"]["name"] = testName;

    var test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
            "size" : 0
    }

    if (testName == "Write Flash Test") {
        test_params["start_addr"] =  toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["size"] =  getValueOf("app.test_params.size");
        strValue = getValueOf("app.test_params.flashtype");
        if (typeof strValue == "string") 
            flash_option = (0xC0000000 | parseInt(strValue.substring(1, strValue.length - 1))) >>> 0;
        else
            flash_option = (0xC0000000 | strValue) >>> 0;
        test_params["params"] = "{0x" + flash_option.toString(16) + ", 0x0}";
    }
    else if (testName == "Write FCB Test") {
        strValue = getValueOf("app.test_params.flashtype");
        if (typeof strValue == "string") 
            flash_option = (0xC0000000 | parseInt(strValue.substring(1, strValue.length - 1))) >>> 0;
        else
            flash_option = (0xC0000000 | strValue) >>> 0;
        test_params["params"] = "{0x" + flash_option.toString(16) + ", 0x0}";
    }
    this.paramsDictionary["app"]["test_params"] = test_params;
}
