"""
Copyright 2019 NXP
"""

import os
import logging
from common.factories import AppInterfaceFactory


class AppInterface(AppInterfaceFactory):
    """
    This class models the mapping between entities used by the front-end (magic numbers,
    names of parameters / results) and application-level entities (symbol names / constants)
    """

    INIT = 0x00000000
    WAIT_FOR_INPUT = 0x5588DCFE
    INPUT_RECEIVED = 0x77665544
    CONFIG_RECEIVED = 0x55AA55AA
    RUNNING = 0x1234FEDC
    FINISHED = 0x11223344
    INTERRUPTED = 0x0D0E0A0D

    RESULTS_BUFFER_SIZE = 16

    @classmethod
    def matches(cls, *args):
        """
        Let the factory know that this class can handle the input so it should be instantiated
        """
        return True

    def __init__(self, app_path):
        """
        Constructor
        Asserts test application executable exists
        :param app_path: path of test application
        """
        assert os.path.isfile(app_path)
        self.logger = logging.getLogger(__name__)
        self.app = app_path

    def get_application(self):
        """
        Return path of test application executable
        :return: path of test application executable
        """
        return self.app

    def get_param_symbol(self, param):
        """
        Map python-level param dictionary keys to application-level parameter block symbol names
        :param param: (python-level) parameter name (key)
        """

        symb = {
            'test' : 'TEST_IN.testType',
            'controller': 'TEST_IN.ctrlType',
            'start_addr' : 'TEST_IN.startAddr',
            'size' : 'TEST_IN.size',
            'flags' : 'TEST_IN.flags',
            'semcClockFrq' : 'TEST_IN.semcClockFrq',
            'params' : 'TEST_IN.params'
        }.get(param, None)
        if symb is None:
            self.logger.warning('Unknown parameter: {}!'.format(param))
        return symb

    def get_result_symbol(self, result):
        """
        Map python-level result dictionary keys to application-level output block symbol names
        :param result: (python-level) result name (key)
        """

        symb = {
            'app_state' : 'TEST_OUT.appState',
            'num_records': 'TEST_OUT.pos',
            'debug' : 'TEST_OUT.debug',
            'err_capt_regs' : 'TEST_OUT.errCaptRegs',
            'debug_regs' : 'TEST_OUT.debugRegs'
        }.get(result, None)
        if symb is None:
            self.logger.warning('Unknown result: {}!'.format(result))
        return symb

    def get_test_result_symbol(self, index, field):
        """
        Map python-level test result dictionary keys to application-level test record symbol names
        :param index: test record index
        :param field: (python-level) test record field name (key)
        """

        field_symbol = {
            'state' : 'TEST_OUT.records[{}].state',
            'test_id': 'TEST_OUT.records[{}].testID',
            'data': 'TEST_OUT.records[{}].data'
        }.get(field, None)
        if field_symbol  is None:
            self.logger.warning('Unknown result field: {}!!!'.format(field))
        return field_symbol.format(index) if field_symbol else None
