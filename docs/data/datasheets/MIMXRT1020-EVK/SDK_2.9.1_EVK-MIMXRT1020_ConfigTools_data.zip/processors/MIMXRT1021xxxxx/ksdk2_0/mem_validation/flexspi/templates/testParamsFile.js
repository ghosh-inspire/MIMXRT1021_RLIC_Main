/*
 * Copyright 2018 - 2019 NXP
 * @author Bogdan Oprescu
 */

var TestParamsFile = function() {
    
    function getValueOf(mystring){
        var value = Adapter.getValueOf(mystring);
        return value;
    }

    function toHexStr(d) {
        return  "0x"+(Number(d).toString(16)).toUpperCase();
    }

    this.paramsDictionary = {
        "app" :
        {
            "reset" : true,
            "name" : "",
            "max_timeout" : 35000,
            "test_params" : ""
        },
        "config" :
        {
            "flexspiConfig" : {
            }
        }
    };
    testName = getValueOf("app.name");
    this.paramsDictionary["app"]["name"] = testName;

    var test_params = {};
    if (testName == "Read-Vendor-ID") {
        test_params = {
            "controller" : 2,
            "start_addr" : "0x80000000",
            "size" : 0
        };
    }
    else {
        test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
			"size" : 0
        }
        test_params["start_addr"] =  toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["size"] =  getValueOf("app.test_params.size");
    }
    this.paramsDictionary["app"]["test_params"] = test_params;
}
