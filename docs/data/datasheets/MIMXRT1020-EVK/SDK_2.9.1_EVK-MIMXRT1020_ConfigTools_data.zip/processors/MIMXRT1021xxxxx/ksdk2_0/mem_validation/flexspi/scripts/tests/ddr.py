"""
Copyright 2019 NXP
"""

import os
import logging
from common.test import BaseTest

class DDRTest(BaseTest):

    def initialize_path():
        """
        Select binary application from the expected location
        """
        bin_dir_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../binaries/'))
        bin_file = next(iter(filter(lambda x: x[-4:] == '.axf', os.listdir(bin_dir_path))))
        binary_path = os.path.join(bin_dir_path, bin_file).replace('\\', '/')
        logging.getLogger(__name__).info('Using binary {}'.format(binary_path))
        return binary_path

    BINARY = initialize_path()


class WRCTest(DDRTest):
    ID = 1
    NAME = 'Write-Read-Compare'

class DMATest(DDRTest):
    ID = 2
    NAME = 'DMA'

    def __init__(self, params):
        super(DMATest, self).__init__(params)

        # Handle unusual params - until they are treated uniformly in upper layers
        if 'src_addr' in self.params['app']['test_params']:
            self.params['app']['test_params']['start_addr'] = self.params['app']['test_params']['src_addr']
            del self.params['app']['test_params']['src_addr']
        if 'dest_addr' in self.params['app']['test_params']:
            self.params['app']['test_params']['params'] = '{ 0,' + self.params['app']['test_params']['dest_addr'] + '}'
            del self.params['app']['test_params']['dest_addr']

class WOTest(DDRTest):
    ID = 3
    NAME = 'Walking Ones'

    def __init__(self, params):
        super(WOTest, self).__init__(params)

        # Handle unusual params - until they are treated uniformly in upper layers
        if 'flags' not in self.params['app']['test_params']:
            custom_flags = {
                '1_byte_access' : 1,
                '2_byte_access' : 2,
                '4_byte_access' : 4
            }
            flags = 0
            for f in custom_flags.keys():
                if f in self.params['app']['test_params']:
                    if self.params['app']['test_params'][f]:
                        flags += custom_flags[f]
                    del self.params['app']['test_params'][f]
            self.params['app']['test_params']['flags'] = flags


class ReadVendorId(DDRTest):
    ID = 200
    NAME = 'Read-Vendor-ID'


class WZTest(WOTest):
    ID = 4
    NAME = 'Walking Zeros'

class StuckAddrTest(DDRTest):
    ID = 5
    NAME = 'Stuck Address'

class RandValueTest(DDRTest):
    ID = 6
    NAME = 'Random Value'

class CompXorTest(DDRTest):
    ID = 7
    NAME = 'Compare XOR'

class CompSubTest(DDRTest):
    ID = 8
    NAME = 'Compare SUB'

class CompMulTest(DDRTest):
    ID = 9
    NAME = 'Compare MUL'

class CompDivTest(DDRTest):
    ID = 10
    NAME = 'Compare DIV'

class CompOrTest(DDRTest):
    ID = 11
    NAME = 'Compare OR'

class CompAndTest(DDRTest):
    ID = 12
    NAME = 'Compare AND'

class SeqIncrTest(DDRTest):
    ID = 13
    NAME = 'Sequential Increment'

class SolBitsTest(DDRTest):
    ID = 14
    NAME = 'Solid Bits'

class BlkSeqTest(DDRTest):
    ID = 15
    NAME = 'Block Sequential'

class ChkBrdTest(DDRTest):
    ID = 16
    NAME = 'Checker Board'

class BitSprTest(DDRTest):
    ID = 17
    NAME = 'Bit Spread'

class BitFlpTest(DDRTest):
    ID = 18
    NAME = 'Bit Flip'

class WBOTest(DDRTest):
    ID = 19
    NAME = 'Walk Bits1'

class WBZTest(DDRTest):
    ID = 20
    NAME = 'Walk Bits0'