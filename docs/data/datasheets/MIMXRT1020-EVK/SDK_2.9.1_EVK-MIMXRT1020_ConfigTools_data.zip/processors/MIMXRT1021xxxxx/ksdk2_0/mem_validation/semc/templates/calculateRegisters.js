/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

function die(errMessage){
    throw new Error(errMessage);
}

var Adapter = scriptApi.getProfile();
var semcConfig = Adapter.getConfiguration();
var semcRegisters = Adapter.getRegisters();

// stop generating SDRAM register initialization when clock is set to an invalid value
var prescale = semcConfig.get("fsl_semc.semc_sdram_config_t.tPrescalePeriod_Ns");
var clockValue = semcConfig.get("fsl_semc.clockConfig.clockSourceFreq");
if (clockValue == null) {
    die("Clock value should not be 0.");
}
if (prescale == null) {
    die("No SDRAM device configured");
}

/** main method that modifies a bit field in a register 
  * @register - register name
  * @bitfield - bit field name
  * @propid - id of the property in the configuration map. The value of the property will be assigned to field
  * @convert - convertion method. Some property values need a conversion from property to bir field value (exp: clock frequency to clock cycles)
  */
function updateBitField(register, bitfield, propId, convert) {
    propValue = semcConfig.get(propId);
    if (propValue == null) {
        die("SEMCProperty data are not synchronized with component data.");
    }

    convertedValue = convert(propValue);
    if (convertedValue == null) {
        die("SEMCProperty data are not synchronized with component data.");
    }
    reg = semcRegisters.get(register);
    if (reg == null) {
        die("SEMCProperty data are not synchronized with component data.");
    }
    reg.updateFieldValue(bitfield, convertedValue >>> 0); 
}

/**
  * Dicrectly updates the value of the register
  * @register - register name
  * @value - new register value
  */
function updateRegister(register, value) {
    semcRegisters.get(register).setValue(value);
}

/** 
  ******************************
  *     Conversion methods     *
  ******************************
  */

/* Identity function for properties which do not need a conversion */
function getValue(value) {
    return value;
}

/* Converts clock frequency to clock cycles */
function convertTiming(time) {
    clock = clockValue;
    clockCycles = 0;

    clock /= 1000000;
    tClk = 1000000 / clock;

    while (tClk * clockCycles < time * 1000) {
        clockCycles++;
    }

    return clockCycles;
}
/* Converts memory size to bitfield value */
function convertSize(size) {
    if (size == "4") {
        return 0x0;
    }
    else if(size == "8") {
        return 0x1;
    }
    else if(size == "16") {
        return 0x2;
    }
    else if(size == "32") {
        return 0x3;
    }
    else if(size == "64") {
        return 0x4;
    }
    else if(size == "128") {
        return 0x5;
    }
    else if(size == "256") {
        return 0x6;
    }
    else if(size == "512") {
        return 0x7;
    }
    else if(size == "1024") {
        return 0x8;
    }
    else if(size == "2048") {
        return 0x9;
    }
    else if(size == "4096") {
        return 0xA;
    }
    else if(size == "8192") {
        return 0xB;
    }
    else if(size == "16384") {
        return 0xC;
    }
    else if(size == "32768") {
        return 0xD;
    }
    else if(size == "65536") {
        return 0xE;
    }
    else if(size == "131072") {
        return 0xF;
    }
    else if(size == "262144") {
        return 0x10;
    }
    else if(size == "524288") {
        return 0x11;
    }
    else if(size == "1048576") {
        return 0x12;
    }
    else if(size == "2097152") {
        return 0x13;
    }
    else if(size == "4194304") {
        return 0x14;
    }
}

/* Transform address to fit the BRx address bit field size */
function shiftAddr(address) {
    /* only 20 high bits in the address are written to CSx register */
    return address >> 12;
}
/* Returns clock cycles - 1. Used for SDRAMCR1 and SDRAMCR2 */
function subTmg(value) {
    ret = convertTiming(value);
    return ret >= 0 ? ret - 1: 0;
}
/* Divide by prescale value. Used for SDRAMCR2 */
function divPrescale(value) {
    return value / prescale;
}
/* Substract one. Used for SDRAMCR3[REBL] */
function sub(value) {
    return value > 0 ? value - 1: 0;
}
/* Compute SDRAMCR3[PREESCALE] value from preescale property value */
function cmpPrescale(prescalePeriod) {
    prescaleReg = (prescalePeriod / 16) / (1000000000 / clockValue);
    return prescaleReg;
}
/**
  * Direct mappings. Mappings between enum elements and field values 
  */

/* SEMC DQS read strobe mode */ 
function mapDQSMode(value) {
    map = {
        "kSEMC_Loopbackinternal" : 0,
        "kSEMC_Loopbackdqspad" : 1
    }
    return map[value];
}
/* Map between IO mux settings and bitfield name in IOCR register */
muxFields = {
    "kSEMC_MUXCSX0" : "MUX_CSX0",
    "kSEMC_MUXCSX1" : "MUX_CSX1",
    "kSEMC_MUXCSX2" : "MUX_CSX2",
    "kSEMC_MUXCSX3" : "MUX_CSX3",
    "kSEMC_MUXRDY"  : "MUX_RDY"
    };
/* SEMC SDRAM Chip selection */
function sdramCSMap(value) {
    map = {
        "kSEMC_SDRAM_CS0": 0,
        "kSEMC_SDRAM_CS1": 1,
        "kSEMC_SDRAM_CS2": 2,
        "kSEMC_SDRAM_CS3": 3
    }
    return map[value];
}
/* SEMC port size */
function mapPS(value) {
    map = {
        "kSEMC_PortSize8Bit":  0,
        "kSEMC_PortSize16Bit": 1
        }
    return map[value];
}
/* SEMC sdram burst length */
function mapBL(value) {
    map = {
        "kSEMC_Sdram_BurstLen1": 0,
        "kSEMC_Sdram_BurstLen2": 1,
        "kSEMC_Sdram_BurstLen4": 2,
        "kSEMC_Sdram_BurstLen8": 3
      };
     return map[value]
}
/* CAS latency */
function mapCL(value) {
    map = {
        "kSEMC_LatencyOne":   1,
        "kSEMC_LatencyTwo":   2,
        "kSEMC_LatencyThree": 3
    };
    return map[value];
}
/* SEMC sdram column address bit number */
function mapCOL(value) {
    map = {
        "kSEMC_SdramColunm_12bit": 0,
        "kSEMC_SdramColunm_11bit": 1,
        "kSEMC_SdramColunm_10bit": 2,
        "kSEMC_SdramColunm_9bit":  3
        };
    return map[value];
}

/**************************************
 *    Update bit fields values        *
 *************************************/
 

/** Module Control Register (MCR) */

/** Bus Timeout Cycles */
updateBitField("MCR", "BTO", "fsl_semc.semc_config_t.busTimeoutCycles", getValue);
/** Command Timeout Cycles */
updateBitField("MCR", "CTO", "fsl_semc.semc_config_t.cmdTimeoutCycles", getValue);
/** DQS Mode */
updateBitField("MCR", "DQSMD", "fsl_semc.semc_config_t.dqsMode", mapDQSMode);
/** Module Disable */

/** Master Bus (AXI) Control Register (BMCR0 and BMCR1) */

/** Weight of Slave Hit (Read/Write switch) */
updateBitField("BMCR0", "WRWS", "fsl_semc.semc_config_t.queueWeight.queueaWeight.queueaConfig.slaveHitNoswitch", getValue);
/** Weight of Slave Hit (no read/write switch) */
updateBitField("BMCR0", "WSH", "fsl_semc.semc_config_t.queueWeight.queueaWeight.queueaConfig.slaveHitSwith", getValue);
/** Weight of Aging */
updateBitField("BMCR0", "WAGE", "fsl_semc.semc_config_t.queueWeight.queueaWeight.queueaConfig.aging", getValue);
/** Weight of QoS */
updateBitField("BMCR0", "WQOS", "fsl_semc.semc_config_t.queueWeight.queueaWeight.queueaConfig.qos", getValue);
/** Weight of Bank Rotation */
updateBitField("BMCR1", "WBR", "fsl_semc.semc_config_t.queueWeight.queuebWeight.queuebConfig.bankRotation", getValue);
/** Weight of Read/Write switch */
updateBitField("BMCR1", "WRWS", "fsl_semc.semc_config_t.queueWeight.queuebWeight.queuebConfig.slaveHitSwith", getValue);
/** Weight of Page Hit */
updateBitField("BMCR1", "WPH", "fsl_semc.semc_config_t.queueWeight.queuebWeight.queuebConfig.weightPagehit", getValue);
/** Weight of Aging */
updateBitField("BMCR1", "WAGE", "fsl_semc.semc_config_t.queueWeight.queuebWeight.queuebConfig.aging", getValue);
/** Weight of QoS */
updateBitField("BMCR1", "WQOS", "fsl_semc.semc_config_t.queueWeight.queuebWeight.queuebConfig.qos", getValue);

/** IO Mux Control Register (IOCR) */
/** Base Registers (For SDRA CS devices) BR0-3 */

/** SEMC_CSX3 output selection */
csxValue = semcConfig.get("fsl_semc.semc_sdram_config_t.csxPinMux");
updateBitField("IOCR", muxFields[csxValue], "fsl_semc.semc_sdram_config_t.semcSdramCs", sdramCSMap);
/** Base Address */
updateBitField("BR0", "BA", "fsl_semc.semc_sdram_config_t.address", shiftAddr);
/** Memory size */
updateBitField("BR0", "MS", "fsl_semc.semc_sdram_config_t.memsize_kbytes", convertSize);
/** Valid - set VLD bit to 1*/
 semcConfig.put("fsl_semc.sdramArray.0.vld", 1);
updateBitField("BR0", "VLD", "fsl_semc.sdramArray.0.vld", getValue);

for (cs = 0; cs < 3; cs++) {
    csxValue = semcConfig.get("fsl_semc.sdramArray." + cs + ".csxPinMux_array");
    idx = cs + 1;
    if (csxValue != null) {
        /** SEMC_CSX3 output selection */
        updateBitField("IOCR", muxFields[csxValue], "fsl_semc.sdramArray." + cs + ".semcSdramCs_array", sdramCSMap);
        /** Base Address */
        updateBitField("BR" + idx, "BA", "fsl_semc.sdramArray." + cs + ".address_array", shiftAddr);
        /** Memory size */
        updateBitField("BR" + idx, "MS", "fsl_semc.semc_sdram_config_t.memsize_kbytes", convertSize);
        /** Valid - set VLD bit to 1*/
        semcConfig.put("fsl_semc.sdramArray." + idx + ".vld", 1); 
    }
    else {
        /** Set VLD bit to 0 */
        semcConfig.put("fsl_semc.sdramArray." + idx + ".vld", 0); 
    }
    updateBitField("BR" + idx, "VLD", "fsl_semc.sdramArray." + idx + ".vld", getValue);
}

/** SDRAM control register 0 (SDRAMCR0) */
/** Will be using CS0 settings for control registers, as the rest of the settings are identical accross chip selects */

/** Port Size */
updateBitField("SDRAMCR0", "PS", "fsl_semc.semc_sdram_config_t.portSize", mapPS);
/** Burst Length */
updateBitField("SDRAMCR0", "BL", "fsl_semc.semc_sdram_config_t.burstLen", mapBL);
/** Column address bit number */
updateBitField("SDRAMCR0", "COL", "fsl_semc.semc_sdram_config_t.columnAddrBitNum", mapCOL);
/** CAS Latency */
updateBitField("SDRAMCR0", "CL", "fsl_semc.semc_sdram_config_t.casLatency", mapCL);

/** SDRAM control register 1 (SDRAMCR1) */

/** PRECHARGE to ACT/Refresh wait time */
updateBitField("SDRAMCR1", "PRE2ACT", "fsl_semc.semc_sdram_config_t.tPrecharge2Act_Ns", subTmg);
/** ACT to Read/Write wait time */
updateBitField("SDRAMCR1", "ACT2RW", "fsl_semc.semc_sdram_config_t.tAct2ReadWrite_Ns", subTmg);
/** Refresh recovery time */
updateBitField("SDRAMCR1", "RFRC", "fsl_semc.semc_sdram_config_t.tRefreshRecovery_Ns", subTmg);
/** Write recovery time */
updateBitField("SDRAMCR1", "WRC", "fsl_semc.semc_sdram_config_t.tWriteRecovery_Ns", subTmg);
/** CKE OFF minimum time */
updateBitField("SDRAMCR1", "CKEOFF", "fsl_semc.semc_sdram_config_t.tCkeOff_Ns", subTmg);
/** ACT to Precharge minimum time */
updateBitField("SDRAMCR1", "ACT2PRE", "fsl_semc.semc_sdram_config_t.tAct2Prechage_Ns", subTmg);

/** SDRAM control register 2 (SDRAMCR2) */

/** Self Refresh Recovery time */
updateBitField("SDRAMCR2", "SRRC", "fsl_semc.semc_sdram_config_t.tSelfRefRecovery_Ns", subTmg);
/** Refresh to Refresh wait time */
updateBitField("SDRAMCR2", "REF2REF", "fsl_semc.semc_sdram_config_t.tRefresh2Refresh_Ns", convertTiming);
/** ACT to ACT wait time */
updateBitField("SDRAMCR2", "ACT2ACT", "fsl_semc.semc_sdram_config_t.tAct2Act_Ns", convertTiming);
/** SDRAM Idle timeout */
updateBitField("SDRAMCR2", "ITO", "fsl_semc.semc_sdram_config_t.tIdleTimeout_Ns", divPrescale);

/** SDRAM control register 3 (SDRAMCR3) */

/** Refresh burst length */
updateBitField("SDRAMCR3", "REBL", "fsl_semc.semc_sdram_config_t.refreshBurstLen", sub);
/** Prescaler timer period */
updateBitField("SDRAMCR3", "PRESCALE", "fsl_semc.semc_sdram_config_t.tPrescalePeriod_Ns", cmpPrescale);
/** Refresh timer period */
updateBitField("SDRAMCR3", "RT", "fsl_semc.semc_sdram_config_t.refreshPeriod_nsPerRow", divPrescale);
/** Refresh urgent threshold */
updateBitField("SDRAMCR3", "UT", "fsl_semc.semc_sdram_config_t.refreshUrgThreshold", divPrescale);

/** IP Command control register 0 (IPCR0) */
/** IP Command control register 1 (IPCR1) */
/** IP Command control register 2 (IPCR2) */
updateRegister("IPCR1", 0x2);
updateRegister("IPCR2", 0x0);
