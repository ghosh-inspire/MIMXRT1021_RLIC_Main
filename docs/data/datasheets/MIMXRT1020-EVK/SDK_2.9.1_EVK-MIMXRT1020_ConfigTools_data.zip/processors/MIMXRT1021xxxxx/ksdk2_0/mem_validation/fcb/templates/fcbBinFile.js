/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

var FCBBinFile = function() {

    this.paramsDictionary = {
    };

    content = []

function getRegAsHexStr(value) {
    return "0x" + value.toString(16);
}

/* get register value as Long */
function getRegAsLong(regId) {
    return parseInt(Adapter.getValueOf(regId + ".value"), 16) >>> 0;
}

/* get value of property */
function getValueOf(propId){
    value = Adapter.getValueOf(propId)
    if (value === parseInt(value, 10)) {
        return parseInt(value) >>> 0;
    }
    return value;
}

    var byteArray = Adapter.getBinaryFileContent("/source/fcb.bin");
    content[0] = byteArray.length;
    for (i = 0, k = 0; i < byteArray.length; i += 4, k++) {
        content[k] = (0xFF & byteArray[i]) << 24 | (0xFF & byteArray[i + 1]) << 16 | (0xFF & byteArray[i + 2]) << 8 | (0xFF & byteArray[i + 3]);
    }
    this.paramsDictionary['bytes'] = content;
    this.paramsDictionary['text'] = [""];

}
