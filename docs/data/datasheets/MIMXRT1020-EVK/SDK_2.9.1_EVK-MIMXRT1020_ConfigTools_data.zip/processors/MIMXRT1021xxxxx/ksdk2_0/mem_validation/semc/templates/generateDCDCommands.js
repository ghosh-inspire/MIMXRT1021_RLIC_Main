/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

scriptApi.requireScript("semcInit.js");

function die(errMessage){
    semcCmdsStr.setLength(0);
    throw new Error(errMessage);
}

var Adapter = scriptApi.getProfile();
var semcRegisters = Adapter.getRegisters();
var semcConfig = Adapter.getConfiguration();

endOfLine = Adapter.getEOL();

function getRegAsHexStr(value) {
    return "0x" + value.toString(16);
}

/* get register value as Long */
function getRegAsLong(regId) {
    return semcRegisters.get(regId).getValue() >>> 0;
}

/* get value of property */
function getValueOf(propId){
    return semcConfig.get(propId);
}

/** Generate DCD commands */
semcInitCmds = buildSemcCommands(getRegAsLong, getValueOf);
for (index = 0; index < semcInitCmds.length; index++) {
    semcCmd = semcInitCmds[index];
    semcCmdsStr.append("command: " + semcCmd.command + ", address: " + semcCmd.address + ", value: " + getRegAsHexStr(semcCmd.value) + ", size: 4" + endOfLine);
}
