"""
Copyright 2020 NXP
"""