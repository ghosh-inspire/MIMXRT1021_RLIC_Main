/*
 * Copyright 2018 NXP
 * @author Bogdan Oprescu
 */

var TestParamsFile = function() {
    
    function getValueOf(mystring){
        var value = Adapter.getValueOf(mystring);
        return value;
    }

    function toHexStr(d) {
        return  "0x"+(Number(d).toString(16)).toUpperCase();
    }

    this.paramsDictionary = {
        "app" :
        {
            "reset" : false,
            "name" : "",
            "max_timeout" : 35000,
            "test_params" : ""
        },
        "config" : { }
    };
    testName = getValueOf("app.name");
    this.paramsDictionary["app"]["name"] = testName;

    var test_params = {};
    if (testName == "Write-Read-Compare") {
        test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
            "size" : "",
            "semcClockFrq" : 163577856,
            "params" : "",
            "flags" : 16
        };
        test_params["start_addr"] = toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["size"] = getValueOf("app.test_params.size");
        test_params["params"] = "{" + getValueOf("app.test_params.params") + "}"; 
    }
    else if (testName == "Walking Ones") {
        test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
            "semcClockFrq" : 163577856,
            "size" : "",
            "1_byte_access" : "",
            "2_byte_access" : "",
            "4_byte_access" : ""
        }
        test_params["start_addr"] =  toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["size"] =  getValueOf("app.test_params.size");
        test_params["1_byte_access"] = getValueOf("app.test_params.1_byte_access");
        test_params["2_byte_access"] = getValueOf("app.test_params.2_byte_access");
        test_params["4_byte_access"] = getValueOf("app.test_params.4_byte_access");
    }
    else if (testName == "Walking Zeros") {
        test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
            "semcClockFrq" : 163577856,
            "size" : "",
            "1_byte_access" : "",
            "2_byte_access" : "",
            "4_byte_access" : ""
        }
        test_params["start_addr"] =  toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["size"] =  getValueOf("app.test_params.size");
        test_params["1_byte_access"] = getValueOf("app.test_params.1_byte_access");
        test_params["2_byte_access"] = getValueOf("app.test_params.2_byte_access");
        test_params["4_byte_access"] = getValueOf("app.test_params.4_byte_access");
    }
    else if (testName == "DMA") {
        test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
            "semcClockFrq" : 163577856,
            "dest_addr" : ""
        }
        test_params["start_addr"] =  toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["dest_addr"] =  toHexStr(getValueOf("app.test_params.dest_addr"));
        test_params["size"] =  getValueOf("app.test_params.size");
    }
	else if (testName == "Stress Test") {
		this.paramsDictionary["app"]["single_result"] = false;
        test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
            "semcClockFrq" : 0x9c45630,
        }
        test_params["start_addr"] =  toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["size"] =  getValueOf("app.test_params.size");
    }
    else {
        test_params = {
            "controller" : 1,
            "start_addr" : "0x80000000",
            "semcClockFrq" : 163577856
        }
        test_params["start_addr"] =  toHexStr(getValueOf("app.test_params.start_addr"));
        test_params["size"] =  getValueOf("app.test_params.size");
    }
    this.paramsDictionary["app"]["test_params"] = test_params;
};
