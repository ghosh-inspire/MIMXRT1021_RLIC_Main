"""
Copyright 2019 NXP
"""

import sys, os
import logging
import traceback
from factories import FactoryClass, AppInterfaceFactory, BackendFactory
import time

class BaseTest:
    """
    Base class for implementing tests
    Derived classes can customize behavior.
    The implementation uses generic backend and application interfaces to isolate test logic from
    underlying target connection choice and application specifics respectively
    """

    # register all derived test classes automatically - used for test selection
    __metaclass__ = FactoryClass.RegistryMeta

    logger = logging.getLogger(__name__)
    
    DONE_MARKER = '****DONE****'
    TEST_PASSED = 1
    TEST_FAILED = -1
    TEST_UNDEFINED = 0

    @staticmethod
    def run_tests(input_list):
        """
        Test runner method. For each item in the input_list it invokes the appropriate test
        :param input_list: list of parameters for each test invocation
        """

        for test_params in input_list:
            # Sanity check
            required_keys = set(['app', 'connect'])
            missing_keys = required_keys - set(test_params.keys())
            if missing_keys:
                BaseTest.logger.error('Incomplete parameters: missing {}!'.format(list(missing_keys)))
                assert False
            # Identify the appropriate test class matching the name parameter against all registered test subclasses
            test_name = test_params['app']['name']

            test_cls = next(cls for cls in BaseTest.registry.values() if cls.matches(test_name))
            if test_cls is None:
                BaseTest.logger.error('No matching test class found for {}!'.format(test_name))
            # Instantiate and invoke the test
            test_cls(test_params).run()

    @classmethod
    def matches(cls, name):
        return hasattr(cls, 'NAME') and cls.NAME.lower() == name.lower()

    ctrl_id = {
        'MIMXRT1021xxxxx': 21,
        'MIMXRT1051xxxxB': 51,
        'MIMXRT1052xxxxB': 52,
        'MIMXRT1061xxxxA': 61,
        'MIMXRT1062xxxxA': 62,
        'MIMXRT1064xxxxA': 64,
        'MIMXRT633S': 633,
        'MIMXRT685S': 685
    }

    def __init__(self, params):

        self.params = params
        # Pre-process params - make sure relevant parameters are set
        self.params['app']['test_params']['test'] = self.get_id()
        self.params['app']['test_params']['controller'] = self.ctrl_id[self.params['connect']['soc_name']]
        self.params['app']['bin'] = self.get_binary()
        # instantiate application and backend objects
        self.app = AppInterfaceFactory.make_unique_instance(params['app']['bin'])
        self.backend = BackendFactory.make_unique_instance(params['connect'])
        # gather application results in a dictionary
        sys.stdout.flush()
        self.results = dict()
        # various flags for controlling test execution behavior
        self.run_to_completion = self.params['app'].get('single_result', True)
        self.timeout = self.params['app'].get('max_timeout', 0)

    def get_id(self):
        return self.ID

    def get_binary(self):
        return self.BINARY

    def get_app_state(self):
        """
        Read the state of the application from target
        """
        return int(self.backend.read_symbol(self.app.get_result_symbol('app_state')))

    def is_waiting_for_input(self):
        """
        Utility method to determine if application is waiting for parameters
        """
        return self.get_app_state() == int(self.app.WAIT_FOR_INPUT)

    def is_app_running(self):
        """
        Utility method to determine if application is waiting for parameters
        """
        return self.get_app_state() == int(self.app.RUNNING)

    def save_symbols(self):
        assert os.path.isfile(self.app.get_application())
        sym_file_path = self.app.get_application()[:-3] + 'syms'
        assert os.path.isfile(sym_file_path)
        with open(sym_file_path, 'r') as f:
            for line in f:
                if any(s in line for s in ['_end_noinit']):
                    cols = line.split()
                    self.params['app']['_end_noinit'] = int('0x' + cols[1], 16)

    def prepare_app(self):
        """
        Load application if needed and make sure it is ready to accept parameters
        """
        try:
            app_ready = False if self.params['app'].get('reset', False) else self.is_waiting_for_input()
        except Exception:
            app_ready = False

        if not app_ready:
            self.save_symbols();
            self.backend.load_app(self.app.get_application())
            self.backend.execute()

        assert self.is_waiting_for_input()

    def write_input_params(self):
        """
        Utility method to write test parameters to target
        """
        assert (self.is_waiting_for_input())
        for (k,v) in self.params['app']['test_params'].iteritems():
            self.backend.write_symbol(self.app.get_param_symbol(k), v)
        self.backend.write_symbol(self.app.get_result_symbol('app_state'), self.app.INPUT_RECEIVED)

    def write_config(self):
        """
        Utility method to write configuration data to target
        """
        def _process_level(config_params, prefix):
            """
            Internal recursive method to process a dictionary of configuration parameters
            Assumes dictionary hierarchy matches C-level structure names in application
            """
            for (k,v) in config_params.iteritems():
                symbol = '{}.{}'.format(prefix, k) if prefix else k
                if isinstance(v, dict):
                    _process_level(v, prefix=symbol)
                else:
                    if k == "dcd_bin":
                        self.backend.write_symbol('Image$$DCD_START$$RO$$Base', self.params['app']['_end_noinit'])
                        self.backend.restore_binary(v, self.params['app']['_end_noinit'])
                    else:
                        self.backend.write_symbol(symbol, v)

        if 'config' in self.params:
            _process_level(self.params['config'], None)
            self.backend.write_symbol(self.app.get_result_symbol('app_state'), self.app.CONFIG_RECEIVED)

    def read_results(self):
        """
        Utility method to gather results from target into internal state.
        Use get_results to retrieve the results
        """
        # simple values
        print 'read_results'
        for s in ['app_state', 'num_records']:
            self.results[s] = int(self.backend.read_symbol(self.app.get_result_symbol(s)))
        # lists
        for s in ['debug', 'err_capt_regs', 'debug_regs']:
            self.results[s] = self.backend.read_symbol(self.app.get_result_symbol(s))[1:-1].split(', ')
        # test_results
        self.results['records'] = list()
        for r in range(self.results['num_records']):
            record = dict()
            for f in ['state', 'test_id']:
                record[f] = int(self.backend.read_symbol(self.app.get_test_result_symbol(r, f)))
            record['data'] = self.backend.read_symbol(self.app.get_test_result_symbol(r, 'data'))[1:-1].split(', ')
            self.results['records'].append(record)

    def get_results(self):
        """
        Returns the currently collected results
        """
        return self.results

    def process_results(self):
        """
        Additional processing and output logic that can be performed on the results
        """
        print self.get_results()

    def run_app(self):
        """
        Executes test application based on configuration (strategy, timeouts)
        Can accommodate run-to-completion or continuous-monitoring
        """
        timeout = 30 # 30 seconds
        interval = 1 # 1 second
        if self.run_to_completion:
            # TODO: implement timeout mechanism
            self.backend.execute(True)
            start = time.time()
            while not self.is_waiting_for_input():
                if time.time() - start > timeout:
                    print "Timout expired"
                    break
                time.sleep(interval)
            print 'App finished in ' + str(time.time() - start) + ' s'
            self.read_results()
        else:
            self.backend.execute(True)

            has_results = True
            while (not self.is_waiting_for_input()) or has_results:
                has_results = False
                for r in range(self.app.RESULTS_BUFFER_SIZE):
                    record = dict()
                    record_state = int(self.backend.read_symbol(self.app.get_test_result_symbol(r, 'state')))
                    if record_state != self.TEST_UNDEFINED:
                        for f in ['state', 'test_id']:
                            record[f] = int(self.backend.read_symbol(self.app.get_test_result_symbol(r, f)))
                        record['data'] = self.backend.read_symbol(self.app.get_test_result_symbol(r, 'data'))[1:-1].split(', ')
                        print record
                        # free up record after reading it
                        self.backend.write_symbol(self.app.get_test_result_symbol(r, 'state'), self.TEST_UNDEFINED)
                        has_results = True

    def run(self):
        """
        Main test execution routine.
        The implementation dispatches to specific methods for each stage to allow customization in derived classes
        """

        try:
            # load app if necessary
            self.prepare_app()
            # write test parameters
            self.write_input_params()
            # write configuration data
            self.write_config()
            # execute
            self.run_app()
            # process results
            self.process_results()
        except Exception as err:
              print(traceback.format_exc())
        finally:
            print self.DONE_MARKER
            sys.stdout.flush()


