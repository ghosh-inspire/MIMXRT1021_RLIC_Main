"""
Copyright 2019 NXP
"""

import logging, sys


class FactoryClass(object):
    """
    Generic factory class
    Intended to be subclassed and used with RegistryMeta as metaclass
    """

    # Keep track of instances
    instance_cache = {}
    logger = logging.getLogger(__name__)

    class RegistryMeta(type):
        """
        Meta class to automatically register all subclasses derived from a given base class
        """

        def __init__(cls, name, bases, dct):
            if not hasattr(cls, 'registry'):
                # Create an empty registry if not present (ie this is the base class)
                cls.registry = {}
            else:
                # Store the class to the registry (this is a derived class)
                interface_id = name.lower()
                cls.registry[interface_id] = cls

            super(FactoryClass.RegistryMeta, cls).__init__(name, bases, dct)

    @classmethod
    def make_instance(cls, *args):
        """
        Factory method which selects an actual subclass based on matches() class method
        :param args: arguments to pass when instantiating an object
        """

        # Identify the appropriate class from the registered subclasses
        candidates = [c for c in cls.registry.values() if c.matches(args)]
        if not candidates:
            msg = 'No matching {} subclass found to instantiate!'.format(cls)
            FactoryClass.logger.critical(msg)
            raise RuntimeError(msg)
        elif len(candidates) > 1:
            FactoryClass.logger.warning('Multiple matching {} subclasses found to instantiate: {}!'.format(cls, candidates))
        sub_cls = next(iter(candidates))
        # Return the new instance
        return sub_cls(*args)

    @classmethod
    def make_unique_instance(cls, *args):
        """
        Factory method which selects an actual subclass based on matches() class method
        Keeps track of instances and instantiates a new one only if the arguments differ
        :param args: arguments to pass when instantiating an object
        """
        print "0_make_unique_instance"
        # generate key
        parts = [cls.__name__]
        for arg in args:
            if isinstance(arg, dict):
                # treat dictionaries specially: keep ordered entries
                parts.append('_'.join('{}:{}'.format(k, v) for k, v in sorted(arg.items())))
            else:
                parts.append(repr(arg))

        key = '_'.join(parts)
        hash_key = hash(key)

        if hash_key not in FactoryClass.instance_cache.keys():
            inst = cls.make_instance(*args)
            FactoryClass.instance_cache[hash_key] = inst
            FactoryClass.logger.debug('new instance: {} -> {}]'.format(key, inst))

        sys.stdout.flush()
        return FactoryClass.instance_cache[hash_key]

    @classmethod
    def matches(cls, *args):
        """
        Selection criterion - to be overridden in subclasses
        """
        return False


class AppInterfaceFactory(FactoryClass):
    """
    An AppInterface class abstracts away potential differences in the way applications are built (symbol names etc)
    """

    # register all derived test classes automatically - used for instance factory
    __metaclass__ = FactoryClass.RegistryMeta


class BackendFactory(FactoryClass):
    """
    A Backend class provides a common interface to the underlying backend used to communicate to the target
    """

    # register all derived test classes automatically - used for factory
    __metaclass__ = FactoryClass.RegistryMeta
