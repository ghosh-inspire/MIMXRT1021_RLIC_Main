"""
Copyright 2019 NXP
"""