"""
Copyright 2020 NXP
"""

import os, sys
import logging
from common.test import BaseTest
from app import AppInterface
import traceback

class DDRTest(BaseTest):

    def initialize_path():
        """
        Select binary application from the expected location
        """
        bin_dir_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../binaries/'))
        binary_path = os.path.join(bin_dir_path, "mimxrt.axf").replace('\\', '/')
        logging.getLogger(__name__).info('Using binary {}'.format(binary_path))
        return binary_path

    BINARY = initialize_path()

class FlashWR(DDRTest):
    ID = 300
    NAME = 'Write Flash Test'

class TestFCB(DDRTest):
    ID = 301
    NAME = 'Write FCB Test'

    def get_bootapp():
        """
        Select bootable bin to be loaded on the target
        """
        bin_dir_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../binaries/'))
        binary_path = os.path.join(bin_dir_path, "mimxrt.axf").replace('\\', '/')
        logging.getLogger(__name__).info('Using binary {}'.format(binary_path))
        return binary_path

    def __init__(self, params):
        BaseTest.__init__(self, params)
        bin_dir_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../binaries/'))
        bin_file = next(iter(filter(lambda x: x[-4:] == '.bin', os.listdir(bin_dir_path))))
        params['app']['bootapp'] = os.path.join(bin_dir_path, bin_file).replace('\\', '/')
        logging.getLogger(__name__).info('Using boot app {}'.format(params['app']['bootapp']))

class CheckImage(TestFCB):
    ID = 302
    NAME = 'Check Image'


class CheckBoot(DDRTest):
    ID = 301
    NAME = 'Check Boot Test'


    def run(self):
        try:
            # connect to target
            self.backend.connect()

            self.backend.command('p /x $pc')
            self.backend.command('p /x $sp')
            # self.backend.command('x 0x400F8000')
            # continue to breakpoint
            # self.backend.command('continue')

            #load axf
            bin_dir_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../binaries/'))
            axf_file = next(iter(filter(lambda x: x[-4:] == '.axf', os.listdir(bin_dir_path))))
            binary_path = os.path.join(bin_dir_path, axf_file).replace('\\', '/')
            self.backend.load_file(binary_path)

            # read_symbol
            g_magic = self.backend.read_symbol('g_magic')

            # read results
            result = {}

            if int(g_magic) == 0xA0A0A0A:
                result['app_state'] = AppInterface.WAIT_FOR_INPUT
                result['num_records'] = 1
                result['records'] = [{'state': 1}]
            else:
                result['app_state'] = AppInterface.INTERRUPTED
                result['num_records'] = 0
            print result
        except Exception as err:
            print(traceback.format_exc())
        finally:
            print self.DONE_MARKER
            sys.stdout.flush()
