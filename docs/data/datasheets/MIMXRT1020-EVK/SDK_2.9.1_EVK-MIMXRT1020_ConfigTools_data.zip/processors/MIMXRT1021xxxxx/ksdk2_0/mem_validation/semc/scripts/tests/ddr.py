"""
Copyright 2019 NXP
"""

import os
import logging
from common.test import BaseTest

class DDRTest(BaseTest):

    def initialize_path():
        """
        Select binary application from the expected location
        """
        bin_dir_path = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../binaries/'))
        bin_file = next(iter(filter(lambda x: x[-4:] == '.axf', os.listdir(bin_dir_path))))
        binary_path = os.path.join(bin_dir_path, bin_file).replace('\\', '/')
        logging.getLogger(__name__).info('Using binary {}'.format(binary_path))
        return binary_path

    BINARY = initialize_path()


class WRCTest(DDRTest):
    ID = 1
    NAME = 'Write-Read-Compare'

class DMATest(DDRTest):
    ID = 2
    NAME = 'DMA'

    def __init__(self, params):
        super(DMATest, self).__init__(params)

        # Handle unusual params - until they are treated uniformly in upper layers
        if 'src_addr' in self.params['app']['test_params']:
            self.params['app']['test_params']['start_addr'] = self.params['app']['test_params']['src_addr']
            del self.params['app']['test_params']['src_addr']
        if 'dest_addr' in self.params['app']['test_params']:
            self.params['app']['test_params']['params'] = '{ 0,' + self.params['app']['test_params']['dest_addr'] + '}'
            del self.params['app']['test_params']['dest_addr']

class WOTest(DDRTest):
    ID = 3
    NAME = 'Walking Ones'

    def __init__(self, params):
        super(WOTest, self).__init__(params)

        # Handle unusual params - until they are treated uniformly in upper layers
        if 'flags' not in self.params['app']['test_params']:
            custom_flags = {
                '1_byte_access' : 1,
                '2_byte_access' : 2,
                '4_byte_access' : 4
            }
            flags = 0
            for f in custom_flags.keys():
                if f in self.params['app']['test_params']:
                    if self.params['app']['test_params'][f]:
                        flags += custom_flags[f]
                    del self.params['app']['test_params'][f]
            self.params['app']['test_params']['flags'] = flags

class WZTest(WOTest):
    ID = 4
    NAME = 'Walking Zeros'

class StressTest(DDRTest):
    ID = 100
    NAME = 'Stress Test'
