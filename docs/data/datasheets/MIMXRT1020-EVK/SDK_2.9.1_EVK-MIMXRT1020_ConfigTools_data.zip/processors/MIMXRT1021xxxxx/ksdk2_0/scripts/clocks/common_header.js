/*
 * Copyright 2016 Freescale Semiconductor
 * Copyright 2016-2020 NXP
 * To be used with MCUXpresso Config Tools under its Software License Agreement.
 */

function CommonHeaderText() {
return ("/*\n\
 * Copyright 2018-2020 NXP\n\
 * All rights reserved.\n\
 *\n\
 * SPDX-License-Identifier: BSD-3-Clause\n\
 */");
} // CommonHeaderText end