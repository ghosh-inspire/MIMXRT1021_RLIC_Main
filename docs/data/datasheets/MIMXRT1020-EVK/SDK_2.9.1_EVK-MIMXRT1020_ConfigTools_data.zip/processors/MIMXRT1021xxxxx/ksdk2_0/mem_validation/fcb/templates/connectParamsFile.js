/*
 * Copyright 2020 NXP
 * @author Bogdan Oprescu
 */

var ConnectParamsFile = function() {

    function getValueOf(mystring){
        var value = Adapter.getValueOf(mystring);
        return value;
    }

    this.paramsDictionary = {
        "connect" : {
            "soc_name" : "MIMXRT1021xxxxx",
            "reset" : true
        }
    }

    testName = getValueOf("app.name");
    if (testName == "Check Boot Test") {
        this.paramsDictionary["connect"]["reset"] = true;
    }
}