/*
 * Copyright 2018 NXP
 * @author Bogdan Oprescu
 */

var ConnectParamsFile = function() {

    this.paramsDictionary = {
        "connect" : {
            "soc_name" : "MIMXRT1021xxxxx",
            "reset" : true
        }
    };
    //this.paramsDictionary["connect"]["reset"] = Adapter.getValueOf("connect.reset");
}