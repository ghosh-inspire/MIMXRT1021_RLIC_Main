/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

Adapter = scriptApi.getProfile();
var semcCmdsStr = Adapter.getGeneratedCode();

/* SEMC sdram burst length */
function mapBL(value) {
    map = {
        "kSEMC_Sdram_BurstLen1": 0,
        "kSEMC_Sdram_BurstLen2": 1,
        "kSEMC_Sdram_BurstLen4": 2,
        "kSEMC_Sdram_BurstLen8": 3
      };
     return map[value]
}
/* CAS latency */
function mapCL(value) {
    map = {
        "kSEMC_LatencyOne":   1,
        "kSEMC_LatencyTwo":   2,
        "kSEMC_LatencyThree": 3
    };
    return map[value];
}

dcdCmds = { WRITE_VALUE: "write_value",
            WRITE_SET_BITS: "write_set_bits",
            WRITE_CLEAR_BITS: "write_clear_bits",
            CHECK_ALL_BITS_SET: "check_all_bits_set",
            CHECK_ALL_BITS_CLEAR: "check_all_bits_clear",
          }
function buildSemcCommands(getRegAsLong, getValueOf) {

    SEMC_MCR_SWRST_MASK = 1 >>> 0;
    SEMC_MCR_MDIS_MASK  = 2 >>> 0;
    semcCmds = [];
    /* Software reset for SEMC internal logical . */
    semcCmds = [{command: dcdCmds.WRITE_SET_BITS, address: "SEMC_MCR", value: SEMC_MCR_SWRST_MASK, size: 4}];
    semcCmds = semcCmds.concat({command: dcdCmds.CHECK_ALL_BITS_CLEAR, address: "SEMC_MCR", value: SEMC_MCR_SWRST_MASK, size: 4});

    /************************
     *   Register writes    *
     ************************/
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_MCR", value: getRegAsLong("MCR"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_BMCR0", value: getRegAsLong("BMCR0"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_BMCR1", value: getRegAsLong("BMCR1"), size: 4});

    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_CLEAR_BITS, address: "SEMC_MCR", value: SEMC_MCR_MDIS_MASK, size: 4});
    
    /** Configure SDRAM controller in SEMC. */
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_BR0", value: getRegAsLong("BR0"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_BR1", value: getRegAsLong("BR1"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_BR2", value: getRegAsLong("BR2"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_BR3", value: getRegAsLong("BR3"), size: 4});

    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IOCR", value: getRegAsLong("IOCR"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_SDRAMCR0", value: getRegAsLong("SDRAMCR0"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_SDRAMCR1", value: getRegAsLong("SDRAMCR1"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_SDRAMCR2", value: getRegAsLong("SDRAMCR2"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_SDRAMCR3", value: getRegAsLong("SDRAMCR3"), size: 4});

    /**************************
     *       IP Commands      *
     **************************/

    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPCR1", value: getRegAsLong("IPCR1"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPCR2", value: getRegAsLong("IPCR2"), size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPCR0", value: getValueOf("fsl_semc.semc_sdram_config_t.address") >>> 0, size: 4});

    SEMC_INTR_IPCMDDONE_MASK = 0x00000001;
    kSEMC_SDRAMCM_Read         = 0x8; /*!< SDRAM memory read. */
    kSEMC_SDRAMCM_Write        = 0x9; /*!< SDRAM memory write. */
    kSEMC_SDRAMCM_Modeset      = 0xA; /*!< SDRAM MODE SET. */
    kSEMC_SDRAMCM_Active       = 0xB; /*!< SDRAM active. */
    kSEMC_SDRAMCM_AutoRefresh  = 0xC; /*!< SDRAM auto-refresh. */
    kSEMC_SDRAMCM_SelfRefresh  = 0xD; /*!< SDRAM self-refresh. */
    kSEMC_SDRAMCM_Precharge    = 0xE; /*!< SDRAM precharge. */
    kSEMC_SDRAMCM_Prechargeall = 0xF; /*!< SDRAM precharge all. */
    
    SEMC_IPCOMMANDMAGICKEY = 0xA55A >>> 0;
    SEMC_IPCMD_KEY_MASK    = 0xFFFF0000 >>> 0;
    SEMC_IPCMD_KEY_SHIFT   = 16;
    SEMC_IPCMD_KEY         = ((SEMC_IPCOMMANDMAGICKEY << SEMC_IPCMD_KEY_SHIFT) & SEMC_IPCMD_KEY_MASK) >>> 0;

    /** kSEMC_SDRAMCM_Prechargeall */
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_SET_BITS, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});
    command = (kSEMC_SDRAMCM_Prechargeall | SEMC_IPCMD_KEY) >>> 0;
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPCMD", value: command, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.CHECK_ALL_BITS_SET, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});

    /** kSEMC_SDRAMCM_AutoRefresh */
    command = (kSEMC_SDRAMCM_AutoRefresh | SEMC_IPCMD_KEY) >>> 0;
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPCMD", value: command, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.CHECK_ALL_BITS_SET, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});

    /** kSEMC_SDRAMCM_AutoRefresh */
    command = (kSEMC_SDRAMCM_AutoRefresh | SEMC_IPCMD_KEY) >>> 0;
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPCMD", value: command, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.CHECK_ALL_BITS_SET, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});

    /** kSEMC_SDRAMCM_Modeset*/
    mode =  mapBL(getValueOf("fsl_semc.semc_sdram_config_t.burstLen")) | (mapCL(getValueOf("fsl_semc.semc_sdram_config_t.casLatency")) << 4)
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPTXDAT", value: mode >>> 0, size: 4});
    command = (kSEMC_SDRAMCM_Modeset | SEMC_IPCMD_KEY) >>> 0;
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_IPCMD", value: command, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.CHECK_ALL_BITS_SET, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_VALUE, address: "SEMC_INTR", value: SEMC_INTR_IPCMDDONE_MASK, size: 4});

    /** Enable refresh */
    SEMC_SDRAMCR3_REN_MASK = 1 >>> 0;
    semcCmds = semcCmds.concat({command: dcdCmds.WRITE_SET_BITS, address: "SEMC_SDRAMCR3", value: SEMC_SDRAMCR3_REN_MASK, size: 4});

    return semcCmds;
}