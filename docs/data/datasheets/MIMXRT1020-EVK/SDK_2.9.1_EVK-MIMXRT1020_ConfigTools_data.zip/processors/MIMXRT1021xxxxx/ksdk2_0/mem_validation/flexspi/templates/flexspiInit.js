/**
  * Copyright 2020 NXP
  * All rights reserved
  */
scriptApi.requireScript("flexspiLUTInit.js");

/*
 * @author Bogdan Oprescu
 */
dcdCmds = { WRITE_VALUE: "write_value",
            WRITE_SET_BITS: "write_set_bits",
            WRITE_CLEAR_BITS: "write_clear_bits",
            CHECK_ALL_BITS_SET: "check_all_bits_set",
            CHECK_ALL_BITS_CLEAR: "check_all_bits_clear",
            DELAY: "cmd_delay"
          }

/** Constants */
/* MCR0 */
FLEXSPI_MCR0_SWRESET_MASK = 1;
FLEXSPI_MCR0_MDIS_MASK = 2;
/* DLLCR */
FLEXSPI_DLLCR_DLLEN_MASK = 1;
/* STS0 */
FLEXSPI_STS0_SEQIDLE_MASK = 1;
FLEXSPI_STS0_ARBIDLE_MASK = 2;
/* STS2 */
FLEXSPI_STS2_ASLVLOCK_MASK = 1;
FLEXSPI_STS2_AREFLOCK_MASK = 2;
FLEXSPI_STS2_BSLVLOCK_MASK = 0x10000;
FLEXSPI_STS2_BREFLOCK_MASK = 0x20000;


function FLEXSPI_SoftwareReset() {

    flexspiCmds = [];

    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_SET_BITS, address: "FLEXSPI_MCR0", value: FLEXSPI_MCR0_SWRESET_MASK, size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.CHECK_ALL_BITS_CLEAR, address: "FLEXSPI_MCR0", value: FLEXSPI_MCR0_SWRESET_MASK, size: 4});

    return flexspiCmds;
}

function buildFlexspiCommands(getRegAsLong, getValueOf) {

    flexspiCmds = [];

    /** FlexSPI init */

    /* Software reset for SEMC internal logical . */
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_CLEAR_BITS, address: "FLEXSPI_MCR0", value: FLEXSPI_MCR0_MDIS_MASK, size: 4});
    // flexspiCmds = flexspiCmds.concat(FLEXSPI_SoftwareReset());

    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_MCR0", value: getRegAsLong("MCR0"), size: 4});
    // flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_MCR0", value: 0xffff1012, size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_MCR1", value: getRegAsLong("MCR1"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_MCR2", value: getRegAsLong("MCR2"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_AHBCR", value: getRegAsLong("AHBCR"), size: 4});

    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_AHBRXBUF0CR0" , value: getRegAsLong("AHBRXBUF0CR0"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_AHBRXBUF1CR0" , value: getRegAsLong("AHBRXBUF1CR0"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_AHBRXBUF2CR0" , value: getRegAsLong("AHBRXBUF2CR0"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_AHBRXBUF3CR0" , value: getRegAsLong("AHBRXBUF3CR0"), size: 4});

    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_IPRXFCR", value: getRegAsLong("IPRXFCR"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_IPTXFCR", value: getRegAsLong("IPTXFCR"), size: 4});

    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA1CR0", value: 0, size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA2CR0", value: 0, size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB1CR0", value: 0, size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB2CR0", value: 0, size: 4});

    /** FlexSPI flash config */

    /* Wait for bus idle before change flash configuration. */
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.CHECK_ALL_BITS_SET, address: "FLEXSPI_STS0", value: FLEXSPI_STS0_SEQIDLE_MASK | FLEXSPI_STS0_ARBIDLE_MASK, size: 4});

    /* Configure flash size. */
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA1CR0", value: getRegAsLong("FLSHA1CR0"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA2CR0", value: getRegAsLong("FLSHA2CR0"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB1CR0", value: getRegAsLong("FLSHB1CR0"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB2CR0", value: getRegAsLong("FLSHB2CR0"), size: 4});

      /* Configure flash parameters. */
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA1CR1", value: getRegAsLong("FLSHA1CR1"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA2CR1", value: getRegAsLong("FLSHA2CR1"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB1CR1", value: getRegAsLong("FLSHB1CR1"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB2CR1", value: getRegAsLong("FLSHB2CR1"), size: 4});

    /* Configure AHB operation items. */
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA1CR2", value: getRegAsLong("FLSHA1CR2"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHA2CR2", value: getRegAsLong("FLSHA2CR2"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB1CR2", value: getRegAsLong("FLSHB1CR2"), size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHB2CR2", value: getRegAsLong("FLSHB2CR2"), size: 4});

    /* Configure DLL. */
    dllA = getRegAsLong("DLLACR");
    dllB = getRegAsLong("DLLBCR");
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_DLLACR", value: dllA, size: 4});
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_DLLBCR", value: dllB, size: 4});

    /* Configure write mask. */
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_VALUE, address: "FLEXSPI_FLSHCR4", value: getRegAsLong("FLSHCR4"), size: 4});

    /* Exit stop mode. */
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.WRITE_CLEAR_BITS, address: "FLEXSPI_MCR0", value: FLEXSPI_MCR0_MDIS_MASK, size: 4});

    statusValue = 0;
    if (dllA & FLEXSPI_DLLCR_DLLEN_MASK) {
        statusValue |= FLEXSPI_STS2_ASLVLOCK_MASK | FLEXSPI_STS2_AREFLOCK_MASK;
    }
    if (dllB & FLEXSPI_DLLCR_DLLEN_MASK) {
        statusValue |= FLEXSPI_STS2_BSLVLOCK_MASK  | FLEXSPI_STS2_BREFLOCK_MASK;
    }
    if (statusValue != 0) {
        flexspiCmds = flexspiCmds.concat({command: dcdCmds.CHECK_ALL_BITS_SET, address: "FLEXSPI_STS2", value: statusValue, size: 4});
    }

    /* Wait at least 100 NOPs*/
    flexspiCmds = flexspiCmds.concat({command: dcdCmds.DELAY, address: "FLEXSPI_MCR0", value: 100, size: 4});

    flexspiCmds = flexspiCmds.concat(buildLUTTable(getRegAsLong, getValueOf));
    flexspiCmds = flexspiCmds.concat(FLEXSPI_SoftwareReset());

    return flexspiCmds;
}