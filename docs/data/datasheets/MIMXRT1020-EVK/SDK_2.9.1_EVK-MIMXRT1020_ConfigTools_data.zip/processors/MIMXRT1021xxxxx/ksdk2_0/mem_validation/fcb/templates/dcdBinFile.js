/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

var DCDBinFile = function() {

    this.paramsDictionary = {
    };

    CMD_END = 0xA5A5A5A5;

    DCD_COMMANDS = {
        "unknown": -1,
        "write_value": 0,
        "write_set_bits": 1,
        "write_clear_bits": 2,
        "check_all_bits_set": 3,
        "check_all_bits_clear": 4,
        "cmd_delay": 5
    }

    content = []

    function addCommand(opId, address, value, size){
            command = []
            command[0] = opId;
            command[1] = address;
            command[2] = value;
            command[3] = size;
            content = content.concat(command);
    }

function getRegAsHexStr(value) {
    return "0x" + value.toString(16);
}

/* get register value as Long */
function getRegAsLong(regId) {
    return parseInt(Adapter.getValueOf(regId + ".value"), 16) >>> 0;
}

/* get value of property */
function getValueOf(propId){
    value = Adapter.getValueOf(propId)
    if (value === parseInt(value, 10)) {
        return parseInt(value) >>> 0;
    }
    return value;
}
    content = content.concat([CMD_END]);
    this.paramsDictionary['bytes'] = content;
    this.paramsDictionary['text'] = [""];

}
