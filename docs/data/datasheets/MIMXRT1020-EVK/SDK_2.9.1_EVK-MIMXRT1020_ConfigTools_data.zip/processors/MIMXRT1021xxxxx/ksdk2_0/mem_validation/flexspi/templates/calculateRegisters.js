/**
  * Copyright 2020 NXP
  * All rights reserved
  */

/*
 * @author Bogdan Oprescu
 */

function die(errMessage){
    throw new Error(errMessage);
}

var Adapter = scriptApi.getProfile();
var semcConfig = Adapter.getConfiguration();
var semcRegisters = Adapter.getRegisters();

// stop generating FLXSPI register initialization when clock is set to an invalid value
var clockValue = semcConfig.get("fsl_flexspi.flexspiConfig.clockSourceFreq");
if (clockValue == null) {
    die("Clock value should not be 0.");
}

/** Main method that modifies a bit field in a register 
  * @register - register name
  * @bitfield - bit field name
  * @propid - id of the property in the configuration map. The value of the property will be assigned to field
  * @convert - convertion method. Some property values need a conversion from property to bir field value (exp: clock frequency to clock cycles)
  */
function updateBitField(register, bitfield, propId, convert) {
    propValue = semcConfig.get(propId);
    if (propValue == null) {
        die("SEMCProperty data are not synchronized with component data.");
    }

    convertedValue = convert(propValue);
    if (convertedValue == null) {
        die("SEMCProperty data are not synchronized with component data.");
    }
    reg = semcRegisters.get(register);
    if (reg == null) {
        die("SEMCProperty data are not synchronized with component data.");
    }
    reg.updateFieldValue(bitfield, convertedValue >>> 0); 
}

/** Modifies a bit field using value
  * @register - register name
  * @bitfield - bit field name
  * @value - bit field value 
  */
function updateBitFieldV(register, bitfield, value) {
    reg = semcRegisters.get(register);
    if (reg == null) {
        die("SEMCProperty data are not synchronized with component data.");
    }
    reg.updateFieldValue(bitfield, value >>> 0); 
}
/**
  * Dicrectly updates the value of the register
  * @register - register name
  * @value - new register value
  */
function updateRegister(register, value) {
    semcRegisters.get(register).setValue(value);
}

/** 
  ******************************
  *     Conversion methods     *
  ******************************
  */

/* Identity function for properties which do not need a conversion */
function getValue(value) {
    return value;
}

/* RX Sample Clock */
function mapRxSampleClock(value) {
    map = {
        "kFLEXSPI_ReadSampleClkLoopbackInternally" : 0,
        "kFLEXSPI_ReadSampleClkLoopbackFromDqsPad" : 1,
        "kFLEXSPI_ReadSampleClkLoopbackFromSckPad" : 2,
        "kFLEXSPI_ReadSampleClkExternalInputFromDqsPad" : 3
    };
    return map[value];
}

/* Map boolean values to integer */
function mapBool(value) {
    map = { "false" : 0, "true" : 1 };
    return map[value];
}
/* Divide value by 8. Used for byte groups */
function div8(value) {
    return value >> 3;
}
/* Get flash interview base name depending on the port */
function getFlashReg(index) {
    regName = {
        "kFLEXSPI_PortA1" : "FLSHA1",
        "kFLEXSPI_PortA2" : "FLSHA2",
        "kFLEXSPI_PortB1" : "FLSHB1",
        "kFLEXSPI_PortB2" : "FLSHB2"
    };
    portValue = semcConfig.get("fsl_flexspi.devices_configs." + index + ".transferConfig.port");
    if (portValue != null) {
        return regName[portValue];
    }
    return null;
}
/* Map CSIntervalUnit choice to value */
function getCSIntervalUnit(value) {
    map = {
        "kFLEXSPI_CsIntervalUnit1SckCycle" : 0,
        "kFLEXSPI_CsIntervalUnit256SckCycle" : 1
    };
    return map[value];
}
/* Map AWRWAIT unit */
function getAHBWriteWaitUnit(value) {
    map = {
        "kFLEXSPI_AhbWriteWaitUnit2AhbCycle" : 0,
        "kFLEXSPI_AhbWriteWaitUnit8AhbCycle" : 1,
        "kFLEXSPI_AhbWriteWaitUnit32AhbCycle" : 2,
        "kFLEXSPI_AhbWriteWaitUnit128AhbCycle" : 3,
        "kFLEXSPI_AhbWriteWaitUnit512AhbCycle" : 4,
        "kFLEXSPI_AhbWriteWaitUnit2048AhbCycle" : 5,
        "kFLEXSPI_AhbWriteWaitUnit8192AhbCycle" : 6,
        "kFLEXSPI_AhbWriteWaitUnit32768AhbCycle" : 7
    };
    return map[value];
}
/* Calculate AWR sequence number */
function getAWRSeqNumber(value) {
    if (value > 0) {
        return value - 1;
    }
    return 0;
}
/* Calculate ARD sequence number */
function getARDSeqNumber(value) {
    if (value > 0) {
        return value - 1;
    }
    return 0;
}

/* 0 when write mask is enable, 1 when disabled */

function getEnableWriteMask(value) {
    map = { "false" : 1, "true" : 0 };
    return map[value];
}

/* 1MHz integer constant*/
FREQ_1MHz = 1000000;

kFLEXSPI_DelayCellUnitMin = 75; /* 75ps. */
kFLEXSPI_DelayCellUnitMax = 225; /* 225ps. */

/**************************************
 *    Update bit fields values        *
 *************************************/

/** Module Control Register 0 (MCR0) */

/* Sample Clock source selection for Flash Reading */
updateBitField("MCR0", "RXCLKSRC", "fsl_flexspi.flexspiConfig.rxSampleClock", mapRxSampleClock);
/* Doze mode enable bit */
updateBitField("MCR0", "DOZEEN", "fsl_flexspi.flexspiConfig.enableDoze", mapBool);
/* Time out wait cycle for IP command grant */
updateBitField("MCR0", "IPGRANTWAIT", "fsl_flexspi.flexspiConfig.ipGrantTimeoutCycle", getValue);
/* Timeout wait cycle for AHB command grant. */
updateBitField("MCR0", "AHBGRANTWAIT", "fsl_flexspi.flexspiConfig.ahbConfig.ahbGrantTimeoutCycle", getValue);
/* This bit is used to force SCK output free-running */
updateBitField("MCR0", "SCKFREERUNEN", "fsl_flexspi.flexspiConfig.enableSckFreeRunning", mapBool);
/* Half Speed Serial Flash access Enable. */
updateBitField("MCR0", "HSEN", "fsl_flexspi.flexspiConfig.enableHalfSpeedAccess", mapBool);
/* This bit is to support Flash Octal mode access by combining Port A and B Data pins (SIOA[3:0] and SIOB[3:0]). */
updateBitField("MCR0", "COMBINATIONEN", "fsl_flexspi.flexspiConfig.enableCombination", mapBool);
/* Enable AHB bus Write Access to IP TX FIFO */
updateBitField("MCR0", "ATDFEN", "fsl_flexspi.flexspiConfig.ahbConfig.enableAHBWriteIpTxFifo", mapBool);
/* Enable AHB bus Read Access to IP RX FIFO */
updateBitField("MCR0", "ARDFEN", "fsl_flexspi.flexspiConfig.ahbConfig.enableAHBWriteIpRxFifo", mapBool);

/** Module Control Register 1 (MCR1) */

/* Command Sequence Execution will timeout and abort after SEQWAIT * 1024 Serial Root Clock cycles */
updateBitField("MCR1", "SEQWAIT", "fsl_flexspi.flexspiConfig.seqTimeoutCycle", getValue);
/* AHB Read/Write access to Serial Flash Memory space will timeout if not data received from Flash or data
not transmited after AHBBUSWAIT * 1024 ahb clock cycles, AHB Bus will get an error response */
updateBitField("MCR1", "AHBBUSWAIT", "fsl_flexspi.flexspiConfig.ahbConfig.ahbBusTimeoutCycle", getValue);

/** Module Control Register 2 (MCR2) */

/* Wait cycle (in AHB clock cycle) for idle state before suspended command sequence resumed. */
updateBitField("MCR2", "RESUMEWAIT", "fsl_flexspi.flexspiConfig.ahbConfig.resumeWaitCycle", getValue);
/* SCKB pad can be used as SCKA differential clock output (inverted clock to SCKA). */
updateBitField("MCR2", "SCKBDIFFOPT", "fsl_flexspi.flexspiConfig.enableSckBDiffOpt", mapBool);
/* All external devices are same devices */
updateBitField("MCR2", "SAMEDEVICEEN", "fsl_flexspi.flexspiConfig.enableSameConfigForAll", mapBool);
/* This bit determines whether AHB RX Buffer and AHB TX Buffer will be cleaned automaticaly when FlexSPI returns STOP mode ACK */
updateBitField("MCR2", "CLRAHBBUFOPT", "fsl_flexspi.flexspiConfig.ahbConfig.enableClearAHBBufferOpt", mapBool);


/** AHB Bus Control Register (AHBCR) */

/* AHB Read Address option bit. This option bit is intend to remove AHB burst start address alignment limitation */
updateBitField("AHBCR", "READADDROPT", "fsl_flexspi.flexspiConfig.ahbConfig.enableReadAddressOpt", mapBool);
/* AHB Read Prefetch Enable */
updateBitField("AHBCR", "PREFETCHEN", "fsl_flexspi.flexspiConfig.ahbConfig.enableAHBPrefetch", mapBool);
/* Enable AHB bus bufferable write access support */
updateBitField("AHBCR", "BUFFERABLEEN", "fsl_flexspi.flexspiConfig.ahbConfig.enableAHBBufferable", mapBool);
/* Enable AHB bus cachable read access support. */
updateBitField("AHBCR", "CACHABLEEN", "fsl_flexspi.flexspiConfig.ahbConfig.enableAHBCachable", mapBool);

for (x = 0; x < 4; x++ ) {
    /** AHB RX Buffer 0 Control Register x (AHBRXBUFxCR0) */

    /* AHB Read Prefetch Enable for current AHB RX Buffer corresponding Master. */
    updateBitField("AHBRXBUF" + x + "CR0", "PREFETCHEN", "fsl_flexspi.flexspiConfig.ahbConfig.buffer." + x + ".enablePrefetch", mapBool);
    /* This priority for AHB Master Read which this AHB RX Buffer is assigned. Refer for more details */
    updateBitField("AHBRXBUF" + x + "CR0", "PRIORITY", "fsl_flexspi.flexspiConfig.ahbConfig.buffer." + x + ".priority", getValue);
    /* This AHB RX Buffer is assigned according to AHB Master with ID */
    updateBitField("AHBRXBUF" + x + "CR0", "MSTRID", "fsl_flexspi.flexspiConfig.ahbConfig.buffer." + x + ".masterIndex", getValue);
    /* AHB RX Buffer Size in 64 bits */
    updateBitField("AHBRXBUF" + x + "CR0", "BUFSZ", "fsl_flexspi.flexspiConfig.ahbConfig.buffer." + x + ".bufferSize", div8);
}

/** IP RX FIFO Control Register (IPRXFCR) */

/* Interrupt register bit IPRXWA is set when filling level in IP RX FIFO is no less than Watermark level by FlexSPI. */
updateBitField("IPRXFCR", "RXWMRK", "fsl_flexspi.flexspiConfig.rxWatermark", getValue);

/** IP TX FIFO Control Register (IPTXFCR) */

/* Watermark level is (TXWMRK+1)*64 Bits */
updateBitField("IPTXFCR", "TXWMRK", "fsl_flexspi.flexspiConfig.txWatermark", getValue);

updateRegister("FLSHA1CR0", 0x0);
updateRegister("FLSHA2CR0", 0x0);
updateRegister("FLSHB1CR0", 0x0);
updateRegister("FLSHB2CR0", 0x0);

for (x = 0; x < 4; x++ ) {
    flashReg = getFlashReg(x);
    if (flashReg != null) {
        /** Flash a Control Register 0 (FLSHA1CR0 - FLSHB2CR0) */

        /* Flash Size in KByte */
        updateBitField(flashReg + "CR0", "FLSHSZ", "fsl_flexspi.devices_configs." + x + ".device_struct.flashSize", getValue);

        /** Flash a Control Register 1 */

        /* This field is used to set the minimum interval between flash device Chip selection deassertion and flash device Chip selection assertion */
        updateBitField(flashReg + "CR1", "CSINTERVAL", "fsl_flexspi.devices_configs." + x + ".device_struct.CSInterval", getValue);
        /* CS interval unit */
        updateBitField(flashReg + "CR1", "CSINTERVALUNIT", "fsl_flexspi.devices_configs." + x + ".device_struct.CSIntervalUnit", getCSIntervalUnit);
        /* Serial Flash CS Hold time */
        updateBitField(flashReg + "CR1", "TCSH", "fsl_flexspi.devices_configs." + x + ".device_struct.CSHoldTime", getValue);
        /* Serial Flash CS setup time */
        updateBitField(flashReg + "CR1", "TCSS", "fsl_flexspi.devices_configs." + x + ".device_struct.CSSetupTime", getValue);
        /* Column Address Size. */
        updateBitField(flashReg + "CR1", "CAS", "fsl_flexspi.devices_configs." + x + ".device_struct.columnspace", getValue);
        /* Word Addressable */
        updateBitField(flashReg + "CR1", "WA", "fsl_flexspi.devices_configs." + x + ".device_struct.enableWordAddress", getValue);

        /** Flash a Control Register 2 */

        /* AWRWAIT unit */
        updateBitField(flashReg + "CR2", "AWRWAITUNIT", "fsl_flexspi.devices_configs." + x + ".device_struct.AHBWriteWaitUnit", getAHBWriteWaitUnit);
        /* This field is used to hold AHB Bus ready for AHB write access to wait the programming finished in external device */
        updateBitField(flashReg + "CR2", "AWRWAIT", "fsl_flexspi.devices_configs." + x + ".device_struct.AHBWriteWaitInterval", getValue);
        /* Sequence Number for AHB Write triggered Command */
        updateBitField(flashReg + "CR2", "AWRSEQNUM", "fsl_flexspi.devices_configs." + x + ".device_struct.AWRSeqNumber", getAWRSeqNumber);
        /* Sequence Index for AHB Write triggered Command */
        updateBitField(flashReg + "CR2", "AWRSEQID", "fsl_flexspi.devices_configs." + x + ".device_struct.AWRSeqIndex", getValue);
        /* Sequence Number for AHB Read triggered Command in LUT */
        updateBitField(flashReg + "CR2", "ARDSEQNUM", "fsl_flexspi.devices_configs." + x + ".device_struct.ARDSeqNumber", getARDSeqNumber);
        /* Sequence Index for AHB Read triggered Command in LUT */
        updateBitField(flashReg + "CR2", "ARDSEQID", "fsl_flexspi.devices_configs." + x + ".device_struct.ARDSeqIndex", getValue);

        /** DLL Control Register 0 */
        dllReg = "";
        if (flashReg.startsWith("FLSHA")) {
            dllReg = "DLLACR"
        }
        else {
            dllReg = "DLLBCR"
        }
        
        isUnifiedConfig = true;

        rxSampleClock = semcConfig.get("fsl_flexspi.flexspiConfig.rxSampleClock");
        isSck2Enabled = semcConfig.get("fsl_flexspi.devices_configs." + x + ".device_struct.isSck2Enabled");
        if (rxSampleClock == "kFLEXSPI_ReadSampleClkExternalInputFromDqsPad" && isSck2Enabled == "false") {
            flexspiRootClkStr = semcConfig.get("fsl_flexspi.devices_configs." + x + ".device_struct.flexspiRootCl");
            flexspiRootClk = parseInt(flexspiRootClkStr.trim().replaceAll("UT", ""));
            if (flexspiRootClk >= 100 * FREQ_1MHz) {
                /* DLLEN = 1, SLVDLYTARGET = 0xF, */
                /* DLL calibration enable */
                updateBitFieldV(dllReg, "DLLEN", 1);
                /* The delay target for slave delay line is: ((SLVDLYTARGET+1) * 1/32 * clock cycle of reference clock (serial clock) */
                updateBitFieldV(dllReg, "SLVDLYTARGET", 0xF);
            }
            else {
                dataValidTime = parseInt(semcConfig.get("fsl_flexspi.devices_configs." + x + ".device_struct.dataValidTime"));
                temp     = dataValidTime * 1000; /* Convert data valid time in ns to ps. */
                dllValue = temp / kFLEXSPI_DelayCellUnitMin;
                if (dllValue * kFLEXSPI_DelayCellUnitMin < temp)
                {
                    dllValue++;
                }

                /* Slave clock delay line delay cell number selection override enable */
                updateBitFieldV(dllReg, "OVRDEN", 1);
                /* Slave clock delay line delay cell number selection override value */
                updateBitFieldV(dllReg, "OVRDVAL", dllValue);
            }
        }

        /** Flash Control Register 4 */

        /* Write mask option bit 1. This option bit could be used to remove AHB write burst start address alignment limitation */
        updateBitField("FLSHCR4", "WMOPT1", "fsl_flexspi.devices_configs." + x + ".device_struct.enableWriteMask", getEnableWriteMask);
        if (flashReg.startsWith("FLSHA")) {
            updateBitField("FLSHCR4", "WMENA", "fsl_flexspi.devices_configs." + x + ".device_struct.enableWriteMask", mapBool);
        }
        else if (flashReg.startsWith("FLSHB")) {
            updateBitField("FLSHCR4", "WMENB", "fsl_flexspi.devices_configs." + x + ".device_struct.enableWriteMask", mapBool);
        }
    }
}
